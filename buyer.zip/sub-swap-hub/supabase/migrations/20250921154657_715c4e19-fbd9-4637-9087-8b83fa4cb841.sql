-- Create listings table for YouTube channels
CREATE TABLE public.listings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  youtube_link TEXT NOT NULL,
  price NUMERIC NOT NULL,
  short_description TEXT,
  full_description TEXT,
  images JSONB DEFAULT '[]'::jsonb,
  admin_proof JSONB DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'active',
  subscriber_count TEXT,
  niche TEXT,
  average_views TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Create orders table
CREATE TABLE public.orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id TEXT NOT NULL UNIQUE,
  listing_id UUID NOT NULL REFERENCES public.listings(id),
  buyer_id UUID REFERENCES auth.users(id),
  buyer_email TEXT,
  buyer_gmail_for_transfer TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  payment_proof JSONB DEFAULT '[]'::jsonb,
  amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  admin_notes TEXT,
  buyer_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- RLS Policies for listings
CREATE POLICY "Anyone can view active listings" 
ON public.listings 
FOR SELECT 
USING (status = 'active');

CREATE POLICY "Authenticated users can create listings" 
ON public.listings 
FOR INSERT 
WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own listings" 
ON public.listings 
FOR UPDATE 
USING (auth.uid() = created_by);

-- RLS Policies for orders  
CREATE POLICY "Users can view their own orders" 
ON public.orders 
FOR SELECT 
USING (auth.uid() = buyer_id);

CREATE POLICY "Users can create orders" 
ON public.orders 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own orders" 
ON public.orders 
FOR UPDATE 
USING (auth.uid() = buyer_id);

-- Add triggers for updated_at
CREATE TRIGGER update_listings_updated_at
  BEFORE UPDATE ON public.listings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to generate order IDs
CREATE OR REPLACE FUNCTION public.generate_order_id()
RETURNS TEXT AS $$
DECLARE
  new_id TEXT;
  counter INTEGER;
BEGIN
  -- Get current date in YYYYMMDD format
  SELECT 'YTC-' || TO_CHAR(now(), 'YYYYMMDD') || '-' INTO new_id;
  
  -- Get count of orders for today and add 1
  SELECT COUNT(*) + 1 INTO counter
  FROM public.orders 
  WHERE order_id LIKE new_id || '%';
  
  -- Format counter with leading zeros
  new_id := new_id || LPAD(counter::TEXT, 4, '0');
  
  RETURN new_id;
END;
$$ LANGUAGE plpgsql;