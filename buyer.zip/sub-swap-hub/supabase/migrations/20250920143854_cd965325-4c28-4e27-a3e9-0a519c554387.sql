-- Create channel_listings table to permanently store seller details
CREATE TABLE public.channel_listings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transaction_id TEXT NOT NULL UNIQUE,
  channel_name TEXT NOT NULL,
  channel_url TEXT NOT NULL,
  category TEXT NOT NULL,
  subscriber_count TEXT NOT NULL,
  average_views TEXT NOT NULL,
  monetization_status TEXT NOT NULL,
  asking_price DECIMAL NOT NULL,
  description TEXT,
  screenshots JSONB DEFAULT '[]',
  audio_file_url TEXT,
  status TEXT DEFAULT 'pending_review',
  seller_contact TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create messages table for admin communication
CREATE TABLE public.messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id TEXT NOT NULL UNIQUE,
  user_type TEXT NOT NULL CHECK (user_type IN ('seller', 'buyer', 'admin')),
  user_contact TEXT NOT NULL,
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'audio')),
  file_url TEXT,
  transaction_id TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.channel_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Create policies for channel_listings (everyone can read, insert their own)
CREATE POLICY "Anyone can view channel listings" 
ON public.channel_listings 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create channel listings" 
ON public.channel_listings 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can update their channel listings" 
ON public.channel_listings 
FOR UPDATE 
USING (true);

-- Create policies for messages (everyone can read and insert)
CREATE POLICY "Anyone can view messages" 
ON public.messages 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create messages" 
ON public.messages 
FOR INSERT 
WITH CHECK (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_channel_listings_updated_at
BEFORE UPDATE ON public.channel_listings
FOR EACH ROW
EXECUTE FUNCTION public.trigger_set_timestamp();

-- Create indexes for better performance
CREATE INDEX idx_channel_listings_transaction_id ON public.channel_listings(transaction_id);
CREATE INDEX idx_channel_listings_status ON public.channel_listings(status);
CREATE INDEX idx_messages_message_id ON public.messages(message_id);
CREATE INDEX idx_messages_transaction_id ON public.messages(transaction_id);
CREATE INDEX idx_messages_user_type ON public.messages(user_type);