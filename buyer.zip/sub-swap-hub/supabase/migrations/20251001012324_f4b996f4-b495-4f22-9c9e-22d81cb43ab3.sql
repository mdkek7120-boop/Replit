-- Fix existing admin user setup using a function approach
DO $$
DECLARE
  admin_user_id UUID;
  profile_exists BOOLEAN;
  role_exists BOOLEAN;
BEGIN
  -- Get the admin user ID
  SELECT id INTO admin_user_id 
  FROM auth.users 
  WHERE email = 'mdkek7120@gmail.com'
  LIMIT 1;
  
  IF admin_user_id IS NOT NULL THEN
    -- Check if profile exists
    SELECT EXISTS(
      SELECT 1 FROM public.profiles WHERE user_id = admin_user_id
    ) INTO profile_exists;
    
    -- Create profile if it doesn't exist
    IF NOT profile_exists THEN
      INSERT INTO public.profiles (user_id, email, username, display_name, balance)
      VALUES (
        admin_user_id,
        'mdkek7120@gmail.com',
        'admin_' || substr(admin_user_id::text, 1, 8),
        'mdkek7120@gmail.com',
        0.00
      );
    END IF;
    
    -- Check if admin role exists
    SELECT EXISTS(
      SELECT 1 FROM public.user_roles 
      WHERE user_id = admin_user_id AND role = 'admin'::app_role
    ) INTO role_exists;
    
    -- Create admin role if it doesn't exist
    IF NOT role_exists THEN
      INSERT INTO public.user_roles (user_id, role)
      VALUES (admin_user_id, 'admin'::app_role);
    END IF;
  END IF;
END $$;