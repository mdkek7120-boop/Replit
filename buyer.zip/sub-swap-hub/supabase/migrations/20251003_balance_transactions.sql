-- Balance Transaction History Table
-- Tracks all balance changes for users with admin approval and reason tracking

CREATE TABLE IF NOT EXISTS public.balance_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    transaction_type TEXT NOT NULL CHECK (transaction_type IN ('add', 'withdraw', 'adjustment', 'refund', 'payment')),
    amount DECIMAL(10, 2) NOT NULL,
    balance_before DECIMAL(10, 2) NOT NULL,
    balance_after DECIMAL(10, 2) NOT NULL,
    reason TEXT,
    reference_id TEXT,
    reference_type TEXT,
    status TEXT DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'cancelled', 'failed')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_balance_transactions_user_id ON public.balance_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_balance_transactions_admin_id ON public.balance_transactions(admin_id);
CREATE INDEX IF NOT EXISTS idx_balance_transactions_created_at ON public.balance_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_balance_transactions_type ON public.balance_transactions(transaction_type);

-- Enable RLS
ALTER TABLE public.balance_transactions ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view their own transactions" 
ON public.balance_transactions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all transactions" 
ON public.balance_transactions 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert transactions" 
ON public.balance_transactions 
FOR INSERT 
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update transactions" 
ON public.balance_transactions 
FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- Function to add balance with transaction logging
CREATE OR REPLACE FUNCTION public.add_user_balance(
    p_user_id UUID,
    p_amount DECIMAL(10, 2),
    p_reason TEXT,
    p_reference_id TEXT DEFAULT NULL,
    p_reference_type TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_current_balance DECIMAL(10, 2);
    v_new_balance DECIMAL(10, 2);
    v_transaction_id UUID;
    v_profile_id UUID;
BEGIN
    -- Get current balance and profile ID
    SELECT balance, id INTO v_current_balance, v_profile_id
    FROM public.profiles
    WHERE user_id = p_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'User profile not found';
    END IF;

    -- Calculate new balance
    v_new_balance := v_current_balance + p_amount;

    -- Update profile balance
    UPDATE public.profiles
    SET balance = v_new_balance,
        updated_at = now()
    WHERE user_id = p_user_id;

    -- Create transaction record
    INSERT INTO public.balance_transactions (
        user_id,
        admin_id,
        transaction_type,
        amount,
        balance_before,
        balance_after,
        reason,
        reference_id,
        reference_type,
        status
    ) VALUES (
        p_user_id,
        auth.uid(),
        'add',
        p_amount,
        v_current_balance,
        v_new_balance,
        p_reason,
        p_reference_id,
        p_reference_type,
        'completed'
    ) RETURNING id INTO v_transaction_id;

    -- Log the action
    PERFORM public.log_admin_action(
        'balance_added',
        jsonb_build_object(
            'user_id', p_user_id,
            'amount', p_amount,
            'reason', p_reason,
            'balance_before', v_current_balance,
            'balance_after', v_new_balance
        ),
        'balance_transaction',
        v_transaction_id::TEXT
    );

    -- Create notification for user
    PERFORM public.create_notification(
        p_user_id,
        'Balance Added',
        format('$%s has been added to your account. %s', p_amount, COALESCE(p_reason, '')),
        'balance_add',
        v_transaction_id::TEXT,
        'transaction'
    );

    RETURN v_transaction_id;
END;
$$;

-- Function to withdraw balance with transaction logging
CREATE OR REPLACE FUNCTION public.withdraw_user_balance(
    p_user_id UUID,
    p_amount DECIMAL(10, 2),
    p_reason TEXT,
    p_reference_id TEXT DEFAULT NULL,
    p_reference_type TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_current_balance DECIMAL(10, 2);
    v_new_balance DECIMAL(10, 2);
    v_transaction_id UUID;
    v_profile_id UUID;
BEGIN
    -- Get current balance and profile ID
    SELECT balance, id INTO v_current_balance, v_profile_id
    FROM public.profiles
    WHERE user_id = p_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'User profile not found';
    END IF;

    -- Check if user has sufficient balance
    IF v_current_balance < p_amount THEN
        RAISE EXCEPTION 'Insufficient balance';
    END IF;

    -- Calculate new balance
    v_new_balance := v_current_balance - p_amount;

    -- Update profile balance
    UPDATE public.profiles
    SET balance = v_new_balance,
        updated_at = now()
    WHERE user_id = p_user_id;

    -- Create transaction record
    INSERT INTO public.balance_transactions (
        user_id,
        admin_id,
        transaction_type,
        amount,
        balance_before,
        balance_after,
        reason,
        reference_id,
        reference_type,
        status
    ) VALUES (
        p_user_id,
        auth.uid(),
        'withdraw',
        p_amount,
        v_current_balance,
        v_new_balance,
        p_reason,
        p_reference_id,
        p_reference_type,
        'completed'
    ) RETURNING id INTO v_transaction_id;

    -- Log the action
    PERFORM public.log_admin_action(
        'balance_withdrawn',
        jsonb_build_object(
            'user_id', p_user_id,
            'amount', p_amount,
            'reason', p_reason,
            'balance_before', v_current_balance,
            'balance_after', v_new_balance
        ),
        'balance_transaction',
        v_transaction_id::TEXT
    );

    -- Create notification for user
    PERFORM public.create_notification(
        p_user_id,
        'Balance Withdrawn',
        format('$%s has been withdrawn from your account. %s', p_amount, COALESCE(p_reason, '')),
        'balance_withdraw',
        v_transaction_id::TEXT,
        'transaction'
    );

    RETURN v_transaction_id;
END;
$$;
