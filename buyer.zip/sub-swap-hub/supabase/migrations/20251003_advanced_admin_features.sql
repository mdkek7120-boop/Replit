-- Advanced Admin Panel Features Migration
-- Add ban system, premium listings, request types, activity logs, and enhanced tracking

-- 1. Add user ban system to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_banned BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS ban_reason TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS banned_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS banned_by UUID REFERENCES auth.users(id);
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS last_login_ip TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS registration_ip TEXT;

-- 2. Add premium listing support and monthly revenue to listings
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS is_premium BOOLEAN DEFAULT FALSE;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS monthly_revenue TEXT;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS premium_until TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS view_count INTEGER DEFAULT 0;

-- 3. Enhance messages table for request types
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS request_type TEXT DEFAULT 'general';
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS listing_reference TEXT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS buyer_info JSONB;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS seller_info JSONB;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS admin_response TEXT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS resolved_by UUID REFERENCES auth.users(id);

-- 4. Create activity logs table for audit trail
CREATE TABLE IF NOT EXISTS public.activity_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    action_type TEXT NOT NULL,
    action_details JSONB,
    resource_type TEXT,
    resource_id TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 5. Create notifications table
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL,
    reference_id TEXT,
    reference_type TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 6. Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_is_banned ON public.profiles(is_banned);
CREATE INDEX IF NOT EXISTS idx_listings_is_premium ON public.listings(is_premium);
CREATE INDEX IF NOT EXISTS idx_messages_request_type ON public.messages(request_type);
CREATE INDEX IF NOT EXISTS idx_messages_status ON public.messages(status);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON public.activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_admin_id ON public.activity_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON public.activity_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON public.notifications(is_read);

-- 7. Enable RLS on new tables
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- 8. RLS policies for activity_logs
CREATE POLICY "Admins can view all activity logs" 
ON public.activity_logs 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can insert activity logs" 
ON public.activity_logs 
FOR INSERT 
WITH CHECK (true);

-- 9. RLS policies for notifications
CREATE POLICY "Users can view their own notifications" 
ON public.notifications 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" 
ON public.notifications 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can insert notifications" 
ON public.notifications 
FOR INSERT 
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can insert notifications" 
ON public.notifications 
FOR INSERT 
WITH CHECK (true);

-- 10. Function to log admin actions
CREATE OR REPLACE FUNCTION public.log_admin_action(
    p_action_type TEXT,
    p_action_details JSONB,
    p_resource_type TEXT DEFAULT NULL,
    p_resource_id TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_log_id UUID;
BEGIN
    INSERT INTO public.activity_logs (
        user_id,
        admin_id,
        action_type,
        action_details,
        resource_type,
        resource_id
    ) VALUES (
        auth.uid(),
        auth.uid(),
        p_action_type,
        p_action_details,
        p_resource_type,
        p_resource_id
    ) RETURNING id INTO v_log_id;
    
    RETURN v_log_id;
END;
$$;

-- 11. Function to create notification
CREATE OR REPLACE FUNCTION public.create_notification(
    p_user_id UUID,
    p_title TEXT,
    p_message TEXT,
    p_type TEXT,
    p_reference_id TEXT DEFAULT NULL,
    p_reference_type TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_notification_id UUID;
BEGIN
    INSERT INTO public.notifications (
        user_id,
        title,
        message,
        type,
        reference_id,
        reference_type
    ) VALUES (
        p_user_id,
        p_title,
        p_message,
        p_type,
        p_reference_id,
        p_reference_type
    ) RETURNING id INTO v_notification_id;
    
    RETURN v_notification_id;
END;
$$;

-- 12. Trigger to log user bans
CREATE OR REPLACE FUNCTION public.log_user_ban()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NEW.is_banned = TRUE AND (OLD.is_banned IS NULL OR OLD.is_banned = FALSE) THEN
        PERFORM public.log_admin_action(
            'user_banned',
            jsonb_build_object(
                'user_id', NEW.user_id,
                'ban_reason', NEW.ban_reason,
                'banned_by', NEW.banned_by
            ),
            'profile',
            NEW.id::TEXT
        );
    ELSIF NEW.is_banned = FALSE AND OLD.is_banned = TRUE THEN
        PERFORM public.log_admin_action(
            'user_unbanned',
            jsonb_build_object(
                'user_id', NEW.user_id,
                'unbanned_by', auth.uid()
            ),
            'profile',
            NEW.id::TEXT
        );
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER on_profile_ban_change
    AFTER UPDATE OF is_banned ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.log_user_ban();

-- 13. Trigger to log listing status changes
CREATE OR REPLACE FUNCTION public.log_listing_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM public.log_admin_action(
            'listing_created',
            jsonb_build_object(
                'listing_id', NEW.id,
                'title', NEW.title,
                'price', NEW.price,
                'created_by', NEW.created_by
            ),
            'listing',
            NEW.id::TEXT
        );
    ELSIF TG_OP = 'UPDATE' AND OLD.status != NEW.status THEN
        PERFORM public.log_admin_action(
            'listing_status_changed',
            jsonb_build_object(
                'listing_id', NEW.id,
                'old_status', OLD.status,
                'new_status', NEW.status
            ),
            'listing',
            NEW.id::TEXT
        );
    ELSIF TG_OP = 'DELETE' THEN
        PERFORM public.log_admin_action(
            'listing_deleted',
            jsonb_build_object(
                'listing_id', OLD.id,
                'title', OLD.title
            ),
            'listing',
            OLD.id::TEXT
        );
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER on_listing_change
    AFTER INSERT OR UPDATE OR DELETE ON public.listings
    FOR EACH ROW
    EXECUTE FUNCTION public.log_listing_change();

-- 14. Add admin message policies
CREATE POLICY "Admins can view all messages" 
ON public.messages 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert messages" 
ON public.messages 
FOR INSERT 
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update messages" 
ON public.messages 
FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- 15. Add admin profile policies
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all profiles" 
ON public.profiles 
FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));
