-- Enable RLS on feedback table that was missing it
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;

-- Create policies for feedback table
CREATE POLICY "Users can view all feedback" 
ON public.feedback 
FOR SELECT 
USING (true);

CREATE POLICY "Users can create feedback" 
ON public.feedback 
FOR INSERT 
WITH CHECK (true);