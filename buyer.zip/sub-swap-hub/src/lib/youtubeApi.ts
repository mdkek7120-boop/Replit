const YOUTUBE_API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;

export interface YouTubeChannelData {
  channelId: string;
  title: string;
  description: string;
  subscriberCount: string;
  viewCount: string;
  videoCount: string;
  thumbnailUrl: string;
  customUrl?: string;
}

export async function fetchYouTubeChannelData(handle: string): Promise<YouTubeChannelData | null> {
  try {
    const cleanHandle = handle.replace('@', '').replace('https://youtube.com/', '').replace('https://www.youtube.com/', '');
    
    const url = `https://www.googleapis.com/youtube/v3/channels?part=id,snippet,statistics&forHandle=${cleanHandle}&key=${YOUTUBE_API_KEY}`;
    
    const response = await fetch(url);
    
    if (!response.ok) {
      console.error('YouTube API error:', await response.text());
      return null;
    }
    
    const data = await response.json();
    
    if (!data.items || data.items.length === 0) {
      console.error('No channel found for handle:', handle);
      return null;
    }
    
    const channel = data.items[0];
    
    return {
      channelId: channel.id,
      title: channel.snippet.title,
      description: channel.snippet.description,
      subscriberCount: channel.statistics.subscriberCount || '0',
      viewCount: channel.statistics.viewCount || '0',
      videoCount: channel.statistics.videoCount || '0',
      thumbnailUrl: channel.snippet.thumbnails.high?.url || channel.snippet.thumbnails.default?.url || '',
      customUrl: channel.snippet.customUrl
    };
  } catch (error) {
    console.error('Error fetching YouTube channel data:', error);
    return null;
  }
}
