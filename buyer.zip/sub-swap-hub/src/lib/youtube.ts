const YOUTUBE_API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;

interface YouTubeChannelData {
  subscriberCount: string;
  viewCount: string;
  videoCount: string;
  channelId: string;
  title: string;
}

export async function fetchYouTubeChannelData(channelUrl: string): Promise<YouTubeChannelData | null> {
  if (!YOUTUBE_API_KEY) {
    console.error('YouTube API key not found');
    return null;
  }

  try {
    let channelId = '';

    if (channelUrl.includes('/channel/')) {
      channelId = channelUrl.split('/channel/')[1].split('/')[0].split('?')[0];
    } else if (channelUrl.includes('/@')) {
      const handle = channelUrl.split('/@')[1].split('/')[0].split('?')[0];
      const handleResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=${handle}&key=${YOUTUBE_API_KEY}`
      );
      
      if (!handleResponse.ok) {
        throw new Error('Failed to fetch channel by handle');
      }
      
      const handleData = await handleResponse.json();
      if (handleData.items && handleData.items.length > 0) {
        channelId = handleData.items[0].id;
      } else {
        throw new Error('Channel not found');
      }
    } else if (channelUrl.includes('/user/')) {
      const username = channelUrl.split('/user/')[1].split('/')[0].split('?')[0];
      const userResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=${username}&key=${YOUTUBE_API_KEY}`
      );
      
      if (!userResponse.ok) {
        throw new Error('Failed to fetch channel by username');
      }
      
      const userData = await userResponse.json();
      if (userData.items && userData.items.length > 0) {
        channelId = userData.items[0].id;
      } else {
        throw new Error('Channel not found');
      }
    } else if (channelUrl.includes('/c/')) {
      const customUrl = channelUrl.split('/c/')[1].split('/')[0].split('?')[0];
      const customResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=${customUrl}&key=${YOUTUBE_API_KEY}`
      );
      
      if (!customResponse.ok) {
        throw new Error('Failed to fetch channel by custom URL');
      }
      
      const customData = await customResponse.json();
      if (customData.items && customData.items.length > 0) {
        channelId = customData.items[0].id;
      } else {
        throw new Error('Channel not found');
      }
    } else {
      throw new Error('Invalid YouTube channel URL format');
    }

    if (!channelId) {
      throw new Error('Could not extract channel ID');
    }

    const statsResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=statistics,snippet&id=${channelId}&key=${YOUTUBE_API_KEY}`
    );

    if (!statsResponse.ok) {
      throw new Error('Failed to fetch channel statistics');
    }

    const statsData = await statsResponse.json();

    if (!statsData.items || statsData.items.length === 0) {
      throw new Error('Channel not found');
    }

    const channel = statsData.items[0];
    const stats = channel.statistics;

    return {
      subscriberCount: formatSubscriberCount(stats.subscriberCount),
      viewCount: stats.viewCount,
      videoCount: stats.videoCount,
      channelId: channelId,
      title: channel.snippet.title
    };
  } catch (error) {
    console.error('Error fetching YouTube data:', error);
    return null;
  }
}

function formatSubscriberCount(count: string): string {
  const num = parseInt(count);
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  }
  return count;
}
