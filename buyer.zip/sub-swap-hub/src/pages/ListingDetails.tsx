import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ExternalLink, Users, DollarSign, TrendingUp, CheckCircle, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { PurchaseRequestDialog } from '@/components/PurchaseRequestDialog';

export default function ListingDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [listing, setListing] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);

  useEffect(() => {
    fetchListing();
  }, [id]);

  const fetchListing = async () => {
    try {
      const { data, error } = await supabase
        .from('listings')
        .select(`
          *,
          profiles:created_by (username, email)
        `)
        .eq('id', id)
        .eq('status', 'active')
        .single();

      if (error) throw error;
      setListing(data);
    } catch (error) {
      console.error('Error fetching listing:', error);
      toast({
        title: "Error",
        description: "Failed to load listing details",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-orange-primary"></div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background">
        <h2 className="text-2xl font-bold text-foreground mb-4">Listing Not Found</h2>
        <Button onClick={() => navigate('/')} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Marketplace
        </Button>
      </div>
    );
  }

  const images = Array.isArray(listing.images) ? listing.images : [];
  const adminProof = Array.isArray(listing.admin_proof) ? listing.admin_proof : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Marketplace
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images */}
          <div className="lg:col-span-2 space-y-6">
            {/* Main Image Gallery */}
            <Card>
              <CardContent className="p-6">
                {images.length > 0 ? (
                  <div className="space-y-4">
                    <img 
                      src={images[0]} 
                      alt={listing.title}
                      className="w-full h-96 object-cover rounded-lg"
                    />
                    {images.length > 1 && (
                      <div className="grid grid-cols-4 gap-4">
                        {images.slice(1).map((img: string, idx: number) => (
                          <img 
                            key={idx}
                            src={img} 
                            alt={`${listing.title} ${idx + 2}`}
                            className="w-full h-24 object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                          />
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="w-full h-96 bg-muted rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">No images available</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Description */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">Description</h2>
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {listing.full_description || listing.short_description || 'No description available'}
                </p>
              </CardContent>
            </Card>

            {/* Admin Proof */}
            {adminProof.length > 0 && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold text-foreground mb-4">Verification Proof</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {adminProof.map((proof: string, idx: number) => (
                      <img 
                        key={idx}
                        src={proof} 
                        alt={`Verification proof ${idx + 1}`}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Details & Purchase */}
          <div className="space-y-6">
            {/* Title and Price Card */}
            <Card className="sticky top-4">
              <CardContent className="p-6 space-y-4">
                <div>
                  <h1 className="text-2xl font-bold text-foreground mb-2">{listing.title}</h1>
                  {listing.niche && (
                    <Badge className="bg-orange-primary text-white">{listing.niche}</Badge>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-muted-foreground">Verified by Admin</span>
                </div>

                {/* Price */}
                <div className="border-t border-b border-border py-4">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Price</span>
                    <span className="text-3xl font-bold text-orange-primary">
                      ${Number(listing.price).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Stats */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Subscribers</span>
                    </div>
                    <span className="font-semibold text-foreground">{listing.subscriber_count || 'N/A'}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Avg Views</span>
                    </div>
                    <span className="font-semibold text-foreground">{listing.average_views || 'N/A'}</span>
                  </div>
                </div>

                {/* YouTube Link */}
                {listing.youtube_link && (
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => window.open(listing.youtube_link, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Channel
                  </Button>
                )}

                {/* Purchase Button */}
                <Button 
                  className="w-full bg-orange-primary hover:bg-orange-primary/90 text-white text-lg py-6"
                  onClick={() => setShowPurchaseDialog(true)}
                >
                  Request to Buy
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  By requesting, you agree to contact the seller through our secure platform
                </p>
              </CardContent>
            </Card>

            {/* Seller Info */}
            {listing.profiles && (
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-foreground mb-3">Seller Information</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-full bg-orange-primary/10 flex items-center justify-center">
                        <span className="text-orange-primary font-semibold">
                          {listing.profiles.username?.[0]?.toUpperCase() || 'S'}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{listing.profiles.username || 'Seller'}</p>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs text-muted-foreground">Verified Seller</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Purchase Request Dialog */}
      <PurchaseRequestDialog 
        open={showPurchaseDialog}
        onOpenChange={setShowPurchaseDialog}
        listing={listing}
      />
    </div>
  );
}
