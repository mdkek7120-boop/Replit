import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowLeft, Upload, Mic, X, Loader2, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import ChatWidget from "@/components/ChatWidget";
import { fetchYouTubeChannelData } from "@/lib/youtube";
import { useToast } from "@/hooks/use-toast";

const SellChannel = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userEmail, setUserEmail] = useState<string>('');
  const [formData, setFormData] = useState({
    channelName: "",
    channelLink: "",
    category: "",
    subscriberCount: "",
    averageViews: "",
    monetizationStatus: "",
    askingPrice: "",
    description: "",
    sellerContact: ""
  });
  const [screenshots, setScreenshots] = useState<File[]>([]);
  const [screenshotPreviews, setScreenshotPreviews] = useState<string[]>([]);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string>("");
  const [fetchingYouTubeData, setFetchingYouTubeData] = useState(false);
  const [youtubeDataFetched, setYoutubeDataFetched] = useState(false);

  // Check authentication status
  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setIsLoggedIn(true);
        setUserEmail(session.user.email || '');
      }
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        setIsLoggedIn(true);
        setUserEmail(session.user.email || '');
      } else {
        setIsLoggedIn(false);
        setUserEmail('');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (field === 'channelLink') {
      setYoutubeDataFetched(false);
    }
  };

  const handleFetchYouTubeData = async () => {
    if (!formData.channelLink) {
      toast({
        title: "Error",
        description: "Please enter a YouTube channel URL first",
        variant: "destructive"
      });
      return;
    }

    setFetchingYouTubeData(true);
    try {
      const data = await fetchYouTubeChannelData(formData.channelLink);
      
      if (data) {
        setFormData(prev => ({
          ...prev,
          channelName: data.title || prev.channelName,
          subscriberCount: data.subscriberCount
        }));
        setYoutubeDataFetched(true);
        toast({
          title: "Success!",
          description: `Fetched data for ${data.title} - ${data.subscriberCount} subscribers`,
        });
      } else {
        toast({
          title: "Error",
          description: "Could not fetch YouTube data. Please check the URL and try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch YouTube data. Please enter manually.",
        variant: "destructive"
      });
    } finally {
      setFetchingYouTubeData(false);
    }
  };

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setScreenshots(prev => [...prev, ...files]);
      
      // Create preview URLs
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            setScreenshotPreviews(prev => [...prev, e.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeScreenshot = (index: number) => {
    setScreenshots(prev => prev.filter((_, i) => i !== index));
    setScreenshotPreviews(prev => prev.filter((_, i) => i !== index));
  };

  const openImageModal = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setShowImageModal(true);
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAudioFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate asking price
    const askingPrice = parseFloat(formData.askingPrice);
    if (isNaN(askingPrice) || askingPrice <= 0) {
      toast({
        title: "Invalid Price",
        description: "Please enter a valid numeric price greater than 0",
        variant: "destructive"
      });
      return;
    }
    
    // Generate unique Order ID
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    const orderId = `ORD-${timestamp}-${random}`;
    
    try {
      const { data, error } = await supabase
        .from('channel_listings')
        .insert({
          transaction_id: orderId,
          channel_name: formData.channelName,
          channel_url: formData.channelLink,
          category: formData.category,
          subscriber_count: formData.subscriberCount,
          average_views: formData.averageViews,
          monetization_status: formData.monetizationStatus,
          asking_price: askingPrice,
          description: formData.description,
          screenshots: screenshots.map(file => ({ name: file.name, size: file.size })),
          audio_file_url: audioFile ? `audio/${audioFile.name}` : null,
          seller_contact: formData.sellerContact || 'Not provided',
          status: 'pending'
        })
        .select()
        .single();

      if (error) {
        console.error('Error saving listing:', error);
        toast({
          title: "Submission Failed",
          description: "Error submitting listing. Please try again.",
          variant: "destructive"
        });
        return;
      }

      // Create a formatted message for admin with all submission details
      const messageId = `MSG-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const messageContent = `
📢 New Channel Listing Submission

Order ID: ${orderId}
Channel Name: ${formData.channelName}
Channel URL: ${formData.channelLink}
Category: ${formData.category}
Subscriber Count: ${formData.subscriberCount}
Average Views: ${formData.averageViews}
Monetization Status: ${formData.monetizationStatus}
Asking Price: $${askingPrice.toLocaleString()}
Seller Contact: ${formData.sellerContact || 'Not provided'}

Description:
${formData.description}

Additional Info:
- Screenshots uploaded: ${screenshots.length}
- Audio file: ${audioFile ? 'Yes' : 'No'}
      `.trim();

      // Save message to database
      const { error: messageError } = await supabase
        .from('messages')
        .insert({
          message_id: messageId,
          transaction_id: orderId,
          user_type: 'seller',
          user_contact: formData.sellerContact || userEmail || 'anonymous',
          content: messageContent,
          message_type: 'text',
          status: 'active'
        });

      if (messageError) {
        console.error('Error saving message:', messageError);
        // Don't fail the submission if message fails, just log it
      }

      toast({
        title: "Success!",
        description: `Your channel submission has been sent to admin. Order ID: ${orderId}`,
      });

      // Navigate to confirmation page with the data
      navigate('/sell-confirmation', {
        state: {
          ...formData,
          orderId,
          askingPrice: `$${askingPrice.toLocaleString()}`,
          listingData: data,
          screenshots: screenshots.length,
          hasAudio: !!audioFile
        }
      });
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Submission Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Marketplace
          </Button>
          
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Sell Your YouTube Channel
              </CardTitle>
              <CardDescription>
                Fill out the form below to list your channel for sale
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="channelName">YouTube Channel Name *</Label>
                    <Input
                      id="channelName"
                      value={formData.channelName}
                      onChange={(e) => handleInputChange('channelName', e.target.value)}
                      placeholder="Enter channel name"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="channelLink">Channel Link (URL) *</Label>
                    <div className="flex gap-2">
                      <Input
                        id="channelLink"
                        type="url"
                        value={formData.channelLink}
                        onChange={(e) => handleInputChange('channelLink', e.target.value)}
                        placeholder="https://youtube.com/@channelname"
                        required
                        data-testid="input-channel-url"
                      />
                      <Button
                        type="button"
                        onClick={handleFetchYouTubeData}
                        disabled={fetchingYouTubeData || !formData.channelLink}
                        className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap"
                        data-testid="button-fetch-youtube"
                      >
                        {fetchingYouTubeData ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Fetching...
                          </>
                        ) : youtubeDataFetched ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            Fetched
                          </>
                        ) : (
                          'Auto-Fetch'
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Click "Auto-Fetch" to automatically get subscriber count from YouTube
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category / Niche *</Label>
                    <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tech">Tech</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="gaming">Gaming</SelectItem>
                        <SelectItem value="lifestyle">Lifestyle</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="entertainment">Entertainment</SelectItem>
                        <SelectItem value="food">Food</SelectItem>
                        <SelectItem value="travel">Travel</SelectItem>
                        <SelectItem value="fashion">Fashion & Style</SelectItem>
                        <SelectItem value="pets">Pets & Animals</SelectItem>
                        <SelectItem value="music">Movies & Music</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="subscriberCount">Subscriber Count *</Label>
                    <Input
                      id="subscriberCount"
                      value={formData.subscriberCount}
                      onChange={(e) => handleInputChange('subscriberCount', e.target.value)}
                      placeholder="e.g., 100K, 1.2M"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="averageViews">Average Views per Video *</Label>
                    <Input
                      id="averageViews"
                      value={formData.averageViews}
                      onChange={(e) => handleInputChange('averageViews', e.target.value)}
                      placeholder="e.g., 10K, 50K"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="monetizationStatus">Monetization Status *</Label>
                    <Select value={formData.monetizationStatus} onValueChange={(value) => handleInputChange('monetizationStatus', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="enabled">Enabled</SelectItem>
                        <SelectItem value="disabled">Disabled</SelectItem>
                        <SelectItem value="pending">Pending Review</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="askingPrice">Asking Price (USD) *</Label>
                    <Input
                      id="askingPrice"
                      type="number"
                      value={formData.askingPrice}
                      onChange={(e) => handleInputChange('askingPrice', e.target.value)}
                      placeholder="e.g., 500, 40000"
                      required
                      min="0"
                      step="1"
                      data-testid="input-asking-price"
                    />
                    <p className="text-xs text-muted-foreground">
                      Enter numeric value only (e.g., 500 for $500)
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="sellerContact">Your Contact (Email/Phone) *</Label>
                    <Input
                      id="sellerContact"
                      value={formData.sellerContact}
                      onChange={(e) => handleInputChange('sellerContact', e.target.value)}
                      placeholder="Enter your contact information"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="screenshots">Screenshots Upload (Analytics, Proof)</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <Input
                      id="screenshots"
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleScreenshotUpload}
                      className="hidden"
                    />
                    <Label htmlFor="screenshots" className="cursor-pointer">
                      <span className="text-blue-600 hover:text-blue-700">Click to upload</span> or drag and drop
                    </Label>
                    <p className="text-sm text-gray-500 mt-1">PNG, JPG up to 10MB each</p>
                    {screenshots.length > 0 && (
                      <p className="text-sm text-green-600 mt-2">{screenshots.length} file(s) uploaded</p>
                    )}
                  </div>
                  
                  {/* Image Previews */}
                  {screenshotPreviews.length > 0 && (
                    <div className="grid grid-cols-4 gap-3 mt-4">
                      {screenshotPreviews.map((preview, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={preview}
                            alt={`Screenshot ${index + 1}`}
                            className="w-full h-20 object-cover rounded-lg border cursor-pointer hover:opacity-80"
                            onClick={() => openImageModal(preview)}
                          />
                          <button
                            type="button"
                            onClick={() => removeScreenshot(index)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            ✕
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="audioMessage">Audio/Voice Message (Optional)</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Mic className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <Input
                      id="audioMessage"
                      type="file"
                      accept="audio/*"
                      onChange={handleAudioUpload}
                      className="hidden"
                    />
                    <Label htmlFor="audioMessage" className="cursor-pointer">
                      <span className="text-blue-600 hover:text-blue-700">Click to upload audio</span>
                    </Label>
                    <p className="text-sm text-gray-500 mt-1">MP3, WAV up to 5MB</p>
                    {audioFile && (
                      <p className="text-sm text-green-600 mt-2">{audioFile.name} selected</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description / Notes</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Additional information about your channel..."
                    rows={4}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-orange-primary hover:bg-orange-primary/90 text-white"
                  size="lg"
                >
                  Submit Channel for Review
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Image Modal */}
      <Dialog open={showImageModal} onOpenChange={setShowImageModal}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Screenshot Preview</DialogTitle>
            <button
              onClick={() => setShowImageModal(false)}
              className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            >
              <X className="h-4 w-4" />
            </button>
          </DialogHeader>
          <div className="flex items-center justify-center p-4">
            <img
              src={selectedImage}
              alt="Full size preview"
              className="max-w-full max-h-[70vh] object-contain rounded-lg"
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Chat Widget */}
      <ChatWidget
        isLoggedIn={isLoggedIn}
        userEmail={userEmail}
        userType="seller"
        defaultExpanded={false}
      />
    </div>
  );
};

export default SellChannel;