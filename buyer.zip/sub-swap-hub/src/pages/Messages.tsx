import { useState, useRef } from "react";
import { useParams, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Send, Paperclip, Mic, Image } from "lucide-react";

interface Message {
  id: string;
  sender: 'user' | 'admin';
  content: string;
  type: 'text' | 'image' | 'audio';
  timestamp: Date;
  fileName?: string;
}

const Messages = () => {
  const { transactionId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  
  const { channelName } = location.state || {};
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'admin',
      content: 'Thank you for submitting your channel listing. We have received your application and will review it within 24-48 hours.',
      type: 'text',
      timestamp: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
    }
  ]);
  
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    const message: Message = {
      id: Date.now().toString(),
      sender: 'user',
      content: newMessage,
      type: 'text',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, message]);
    setNewMessage('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const message: Message = {
      id: Date.now().toString(),
      sender: 'user',
      content: `Uploaded file: ${file.name}`,
      type: file.type.startsWith('image/') ? 'image' : 'audio',
      timestamp: new Date(),
      fileName: file.name
    };
    
    setMessages(prev => [...prev, message]);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/sell-confirmation', { state: location.state })}
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Confirmation
          </Button>
          
          <Card className="max-w-4xl mx-auto h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">
                    Support Chat
                  </CardTitle>
                  <p className="text-sm text-gray-600">
                    {channelName && `Channel: ${channelName} • `}
                    Transaction ID: {transactionId}
                  </p>
                </div>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  Active
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col p-0">
              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      message.sender === 'user'
                        ? 'bg-orange-primary text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}>
                      <div className="text-sm">
                        {message.type === 'image' && (
                          <div className="flex items-center mb-1">
                            <Image className="w-4 h-4 mr-1" />
                            <span className="text-xs opacity-75">Image</span>
                          </div>
                        )}
                        {message.type === 'audio' && (
                          <div className="flex items-center mb-1">
                            <Mic className="w-4 h-4 mr-1" />
                            <span className="text-xs opacity-75">Audio</span>
                          </div>
                        )}
                        {message.content}
                      </div>
                      <div className={`text-xs mt-1 ${
                        message.sender === 'user' ? 'text-orange-100' : 'text-gray-500'
                      }`}>
                        {formatTime(message.timestamp)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Input Area */}
              <div className="border-t p-4">
                <div className="flex items-center space-x-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => audioInputRef.current?.click()}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <Mic className="w-4 h-4" />
                  </Button>
                  
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1"
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    className="bg-orange-primary hover:bg-orange-primary/90 text-white"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Hidden file inputs */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <input
                  ref={audioInputRef}
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Messages;