import { useState, useEffect } from "react";
import { Header } from "@/components/marketplace/Header";
import { CategoryFilter } from "@/components/marketplace/CategoryFilter";
import { ChannelCard } from "@/components/marketplace/ChannelCard";
import { TopFilters } from "@/components/marketplace/TopFilters";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { UserProfileDialog } from "@/components/UserProfileDialog";
import { supabase } from "@/integrations/supabase/client";

const Index = () => {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [listings, setListings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, profile } = useAuth();

  useEffect(() => {
    fetchListings();
  }, [selectedCategory]);

  const fetchListings = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('listings')
        .select('*')
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (selectedCategory !== 'all') {
        query = query.eq('niche', selectedCategory);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Transform listings to match ChannelCard format
      const transformedListings = (data || []).map((listing: any) => ({
        id: listing.id,
        title: listing.title,
        category: listing.niche || 'General',
        price: Number(listing.price) || 0,
        subscribers: listing.subscriber_count || 'N/A',
        monthlyIncome: '$' + (listing.average_views || '0'),
        thumbnail: Array.isArray(listing.images) && listing.images.length > 0 
          ? listing.images[0] 
          : 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400&h=300&fit=crop',
        verified: true,
        featured: true,
        badges: ['VERIFIED'],
        sellerRating: 4.8
      }));

      setListings(transformedListings);
    } catch (error) {
      console.error('Error fetching listings:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <TopFilters onViewChange={setViewMode} currentView={viewMode} />
      <CategoryFilter 
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />
      
      <div className="container mx-auto px-4 py-6">
        <div className="space-y-6">
          {/* Top Controls - Actions */}
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Button 
                onClick={() => window.location.href = '/sell'}
                className="bg-orange-primary hover:bg-orange-primary/90 text-white"
                size="sm"
              >
                <Plus className="h-4 w-4 mr-2" />
                YouTube Channel Sell
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-orange-primary border-orange-primary hover:bg-orange-primary hover:text-white"
                onClick={() => window.location.href = '/admin/messages'}
              >
                Message Admin
              </Button>
              {user && profile && (
                <UserProfileDialog user={user} profile={profile} />
              )}
            </div>
          </div>

          {/* Channel Grid/List */}
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-primary"></div>
            </div>
          ) : listings.length > 0 ? (
            <div className={
              viewMode === "grid" 
                ? "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6" 
                : "space-y-4"
            }>
              {listings.map((channel) => (
                <ChannelCard key={channel.id} channel={channel} viewMode={viewMode} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No listings available at the moment.</p>
            </div>
          )}

          {/* Load More */}
          <div className="flex justify-center mt-12">
            <Button 
              variant="outline" 
              className="px-8 py-3 border-orange-primary text-orange-primary hover:bg-orange-primary hover:text-white"
            >
              Load More Channels
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;