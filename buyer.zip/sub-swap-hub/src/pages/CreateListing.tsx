import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Youtube, Upload, DollarSign, Users, Eye, TrendingUp, ArrowLeft, Loader2, Check } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { fetchYouTubeChannelData } from '@/lib/youtubeApi';

const CreateListing = () => {
  const navigate = useNavigate();
  const { user, isAdmin, loading } = useAuth();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [channelDataFetched, setChannelDataFetched] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    youtube_link: '',
    price: '',
    niche: '',
    subscriber_count: '',
    average_views: '',
    monthly_revenue: '',
    short_description: '',
    full_description: '',
    monetization_status: 'monetized',
    is_premium: false,
    status: 'active'
  });
  const [images, setImages] = useState<string[]>([]);
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [youtubeHandle, setYoutubeHandle] = useState('');

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      toast({
        title: "Access Denied",
        description: "Only administrators can create listings",
        variant: "destructive"
      });
      navigate('/admin/login');
    }
  }, [user, isAdmin, loading, navigate, toast]);

  const categories = [
    'Gaming',
    'Music',
    'Technology',
    'Education',
    'Entertainment',
    'Comedy',
    'News & Politics',
    'Sports',
    'Travel',
    'Food & Cooking',
    'Beauty & Fashion',
    'Health & Fitness',
    'Business & Finance',
    'Science',
    'DIY & Crafts',
    'Kids & Family',
    'Vlog',
    'Animation',
    'Documentary',
    'Other'
  ];

  const handleFetchChannelData = async () => {
    if (!youtubeHandle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a YouTube channel handle",
        variant: "destructive"
      });
      return;
    }

    setIsFetching(true);
    try {
      const data = await fetchYouTubeChannelData(youtubeHandle);
      
      if (!data) {
        toast({
          title: "Error",
          description: "Could not fetch channel data. Please check the handle and try again.",
          variant: "destructive"
        });
        return;
      }

      setFormData(prev => ({
        ...prev,
        title: data.title,
        youtube_link: `https://youtube.com/@${youtubeHandle.replace('@', '')}`,
        subscriber_count: data.subscriberCount,
        short_description: data.description.substring(0, 150),
        full_description: data.description
      }));
      
      setThumbnailUrl(data.thumbnailUrl);
      setChannelDataFetched(true);
      
      toast({
        title: "Success!",
        description: `Fetched data for ${data.title}`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to fetch channel data",
        variant: "destructive"
      });
    } finally {
      setIsFetching(false);
    }
  };

  const extractYouTubeData = (url: string) => {
    if (!url) return;

    try {
      const urlObj = new URL(url);
      let videoId = '';

      if (urlObj.hostname.includes('youtu.be')) {
        videoId = urlObj.pathname.slice(1).split('?')[0];
      } else if (urlObj.hostname.includes('youtube.com')) {
        if (urlObj.pathname.includes('/watch')) {
          videoId = urlObj.searchParams.get('v') || '';
        } else if (urlObj.pathname.includes('/channel') || urlObj.pathname.includes('/@')) {
          const channelMatch = urlObj.pathname.match(/\/(channel|@)\/([^\/]+)/);
          if (channelMatch) {
            setThumbnailUrl(`https://via.placeholder.com/400x300?text=YouTube+Channel`);
            return;
          }
        }
      }

      if (videoId) {
        setThumbnailUrl(`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`);
      }
    } catch (error) {
      console.error('Error extracting YouTube data:', error);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    if (field === 'youtube_link') {
      extractYouTubeData(value);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: string[] = [];
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        newImages.push(reader.result as string);
        if (newImages.length === files.length) {
          setImages(prev => [...prev, ...newImages]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.youtube_link || !formData.price) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);

    try {
      const listingData = {
        title: formData.title,
        youtube_link: formData.youtube_link,
        price: parseFloat(formData.price),
        niche: formData.niche,
        subscriber_count: formData.subscriber_count,
        average_views: formData.average_views,
        monthly_revenue: formData.monthly_revenue,
        short_description: formData.short_description,
        full_description: formData.full_description,
        status: formData.status,
        created_by: user?.id,
        images: images.length > 0 ? images : (thumbnailUrl ? [thumbnailUrl] : null),
        admin_proof: {
          monetization_status: formData.monetization_status,
          is_premium: formData.is_premium,
          created_by_admin: true,
          created_at: new Date().toISOString()
        }
      };

      const { data, error } = await supabase
        .from('listings')
        .insert([listingData])
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Success!",
        description: "YouTube channel listing created successfully",
      });

      navigate('/admin/dashboard');
    } catch (error: any) {
      console.error('Error creating listing:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create listing",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Create YouTube Channel Listing</h1>
              <p className="text-muted-foreground">Admin-only listing creation</p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => navigate('/admin/dashboard')}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* YouTube Auto-Fetch Section */}
              <Card className="border-orange-primary/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Youtube className="w-5 h-5 text-orange-primary" />
                    Auto-Fetch Channel Data
                  </CardTitle>
                  <CardDescription>
                    Enter a YouTube channel handle to automatically fetch real data
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Input
                        placeholder="@crazy4bollywood or @technoruhez"
                        value={youtubeHandle}
                        onChange={(e) => setYoutubeHandle(e.target.value)}
                        disabled={isFetching}
                        className="border-orange-primary/30"
                      />
                    </div>
                    <Button 
                      type="button"
                      onClick={handleFetchChannelData} 
                      disabled={isFetching}
                      className="bg-orange-primary hover:bg-orange-primary/90"
                    >
                      {isFetching ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Fetching...
                        </>
                      ) : channelDataFetched ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Fetched
                        </>
                      ) : (
                        <>
                          <Youtube className="w-4 h-4 mr-2" />
                          Fetch Data
                        </>
                      )}
                    </Button>
                  </div>

                  {channelDataFetched && thumbnailUrl && (
                    <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-900 rounded-lg">
                      <div className="flex items-start gap-4">
                        <img 
                          src={thumbnailUrl} 
                          alt={formData.title}
                          className="w-20 h-20 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-bold text-lg">{formData.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {parseInt(formData.subscriber_count || '0').toLocaleString()} subscribers
                          </p>
                          <Badge className="mt-2 bg-green-600">Data Fetched Successfully</Badge>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>Enter the channel details and pricing</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="title">Channel Title *</Label>
                    <Input
                      id="title"
                      data-testid="input-title"
                      placeholder="e.g., The Plot Watcher"
                      value={formData.title}
                      onChange={(e) => handleInputChange('title', e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="youtube_link">YouTube Channel Link *</Label>
                    <div className="relative">
                      <Youtube className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="youtube_link"
                        data-testid="input-youtube-link"
                        className="pl-9"
                        placeholder="https://www.youtube.com/@channel or https://youtu.be/..."
                        value={formData.youtube_link}
                        onChange={(e) => handleInputChange('youtube_link', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="price">Price (USD) *</Label>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="price"
                          data-testid="input-price"
                          type="number"
                          className="pl-9"
                          placeholder="499"
                          value={formData.price}
                          onChange={(e) => handleInputChange('price', e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="niche">Category/Niche *</Label>
                      <Select
                        value={formData.niche}
                        onValueChange={(value) => handleInputChange('niche', value)}
                      >
                        <SelectTrigger data-testid="select-niche">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(cat => (
                            <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="subscribers">Subscriber Count</Label>
                      <div className="relative">
                        <Users className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="subscribers"
                          data-testid="input-subscribers"
                          className="pl-9"
                          placeholder="1650 subs"
                          value={formData.subscriber_count}
                          onChange={(e) => handleInputChange('subscriber_count', e.target.value)}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="average_views">Average Views</Label>
                      <div className="relative">
                        <Eye className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="average_views"
                          data-testid="input-average-views"
                          className="pl-9"
                          placeholder="10K views"
                          value={formData.average_views}
                          onChange={(e) => handleInputChange('average_views', e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="monthly_revenue">Monthly Revenue</Label>
                    <div className="relative">
                      <TrendingUp className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="monthly_revenue"
                        data-testid="input-monthly-revenue"
                        className="pl-9"
                        placeholder="$600/month"
                        value={formData.monthly_revenue}
                        onChange={(e) => handleInputChange('monthly_revenue', e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="short_description">Short Description</Label>
                    <Input
                      id="short_description"
                      data-testid="input-short-description"
                      placeholder="Brief channel description"
                      value={formData.short_description}
                      onChange={(e) => handleInputChange('short_description', e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="full_description">Full Description</Label>
                    <Textarea
                      id="full_description"
                      data-testid="textarea-full-description"
                      placeholder="Detailed channel information, growth potential, audience demographics, etc."
                      rows={6}
                      value={formData.full_description}
                      onChange={(e) => handleInputChange('full_description', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Channel Screenshots & Images</CardTitle>
                  <CardDescription>Upload screenshots of analytics, channel page, etc.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="images">Upload Images</Label>
                    <div className="mt-2">
                      <label
                        htmlFor="images"
                        className="flex items-center justify-center w-full px-4 py-8 border-2 border-dashed border-border rounded-lg cursor-pointer hover:border-primary transition-colors"
                      >
                        <div className="text-center">
                          <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                          <p className="mt-2 text-sm text-muted-foreground">
                            Click to upload or drag and drop
                          </p>
                          <p className="text-xs text-muted-foreground">
                            PNG, JPG, GIF up to 10MB
                          </p>
                        </div>
                        <Input
                          id="images"
                          data-testid="input-images"
                          type="file"
                          className="hidden"
                          accept="image/*"
                          multiple
                          onChange={handleImageUpload}
                        />
                      </label>
                    </div>
                  </div>

                  {images.length > 0 && (
                    <div className="grid grid-cols-3 gap-4">
                      {images.map((img, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={img}
                            alt={`Screenshot ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border border-border"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="destructive"
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => removeImage(index)}
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  {thumbnailUrl && (
                    <img
                      src={thumbnailUrl}
                      alt="Channel thumbnail"
                      className="w-full rounded-lg border border-border mb-4"
                    />
                  )}
                  {formData.title && (
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{formData.title}</h3>
                      {formData.niche && (
                        <Badge variant="secondary" className="mb-2">{formData.niche}</Badge>
                      )}
                      {formData.price && (
                        <p className="text-2xl font-bold text-primary">${formData.price}</p>
                      )}
                      {formData.subscriber_count && (
                        <p className="text-sm text-muted-foreground mt-2">
                          {formData.subscriber_count}
                        </p>
                      )}
                      {formData.monthly_revenue && (
                        <p className="text-sm text-muted-foreground">
                          Revenue: {formData.monthly_revenue}
                        </p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Listing Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => handleInputChange('status', value)}
                    >
                      <SelectTrigger data-testid="select-status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="monetization">Monetization Status</Label>
                    <Select
                      value={formData.monetization_status}
                      onValueChange={(value) => handleInputChange('monetization_status', value)}
                    >
                      <SelectTrigger data-testid="select-monetization">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monetized">Monetized</SelectItem>
                        <SelectItem value="not_monetized">Not Monetized</SelectItem>
                        <SelectItem value="eligible">Eligible for Monetization</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="is_premium">Premium Listing</Label>
                      <p className="text-xs text-muted-foreground">Featured at top</p>
                    </div>
                    <Switch
                      id="is_premium"
                      data-testid="switch-premium"
                      checked={formData.is_premium}
                      onCheckedChange={(checked) => handleInputChange('is_premium', checked)}
                    />
                  </div>
                </CardContent>
              </Card>

              <Button
                type="submit"
                className="w-full bg-orange-primary hover:bg-orange-primary/90"
                disabled={submitting}
                data-testid="button-create-listing"
              >
                {submitting ? 'Creating...' : 'Create Listing'}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateListing;
