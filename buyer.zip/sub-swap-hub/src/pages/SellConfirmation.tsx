import { useLocation, useNavigate, Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, MessageSquare, ArrowLeft } from "lucide-react";

const SellConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const formData = location.state;

  if (!formData) {
    return <Navigate to="/sell" replace />;
  }

  const orderId = formData.orderId || formData.transactionId;

  const handleMessageAdmin = () => {
    navigate(`/messages/${orderId}`, { 
      state: { transactionId: orderId, channelName: formData.channelName } 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Marketplace
          </Button>
          
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <CheckCircle className="w-16 h-16 text-green-500" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Submission Successful!
              </CardTitle>
              <p className="text-gray-600">
                Your channel listing has been submitted for review
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">✓ Your submission was sent to the admin</h3>
                <p className="text-sm text-blue-800">
                  We have received your submission. The details you provided are below for your records.
                </p>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-3">Your Submission Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Order ID:</span>
                    <span className="font-medium font-mono text-blue-600" data-testid="text-order-id">{orderId}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Status:</span>
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                      Pending Review
                    </Badge>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Channel Name:</span>
                    <span className="font-medium break-all">{formData.channelName}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Channel URL:</span>
                    <span className="font-medium text-blue-600 break-all text-xs">{formData.channelLink}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Category:</span>
                    <span className="font-medium">{formData.category}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Subscriber Count:</span>
                    <span className="font-medium">{formData.subscriberCount}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Average Views:</span>
                    <span className="font-medium">{formData.averageViews}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Monetization Status:</span>
                    <span className="font-medium">{formData.monetizationStatus}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Asking Price:</span>
                    <span className="font-medium text-green-600">{formData.askingPrice}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-600">Your Contact:</span>
                    <span className="font-medium">{formData.sellerContact || 'Not provided'}</span>
                  </div>
                  {formData.description && (
                    <div className="pt-2">
                      <span className="text-gray-600 block mb-1">Description:</span>
                      <p className="text-gray-900 bg-white p-2 rounded border text-xs">{formData.description}</p>
                    </div>
                  )}
                  {(formData.screenshots || formData.hasAudio) && (
                    <div className="pt-2">
                      <span className="text-gray-600 block mb-1">Attachments:</span>
                      <div className="text-gray-900 bg-white p-2 rounded border text-xs">
                        {formData.screenshots > 0 && <div>• Screenshots: {formData.screenshots} file(s)</div>}
                        {formData.hasAudio && <div>• Audio file included</div>}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">What happens next?</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Our team will review your channel within 24-48 hours</li>
                  <li>• You'll receive an email notification about the status</li>
                  <li>• You can message our admin team for any questions</li>
                  <li>• Keep your Order ID safe for future reference</li>
                </ul>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={handleMessageAdmin}
                  className="flex-1 bg-orange-primary hover:bg-orange-primary/90 text-white"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Message Admin
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => navigate('/')}
                  className="flex-1"
                >
                  Browse Marketplace
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SellConfirmation;