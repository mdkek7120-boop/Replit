import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

const SeedListings = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [seeded, setSeeded] = useState(false);
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data: roles } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id);
        
        setIsAdmin(roles?.some(r => r.role === 'admin') || user.email === 'mdkek7120@gmail.com');
      }
    } catch (error) {
      console.error('Error checking admin status:', error);
    } finally {
      setChecking(false);
    }
  };

  const seedListings = async () => {
    setLoading(true);
    try {
      const listings = [
        {
          title: 'The Plot Watcher',
          youtube_link: 'https://youtu.be/C9wtDn4ZQdo?si=Xehhth5vvhP1X2tB',
          niche: 'Movies & Music',
          price: 499,
          subscriber_count: '1650',
          average_views: '600',
          short_description: 'Popular movie and music review channel with engaged audience',
          full_description: 'This channel focuses on movie reviews, music analysis, and entertainment content. Great engagement rate with loyal subscriber base. Monetized and ready for immediate transfer.',
          status: 'active',
          images: ['https://img.youtube.com/vi/C9wtDn4ZQdo/maxresdefault.jpg']
        },
        {
          title: 'Quick Flick',
          youtube_link: 'https://youtu.be/Tt42IVL0aUM?si=tMj_gqPvU2abmWgf',
          niche: 'Educational & QA',
          price: 1249,
          subscriber_count: '6610',
          average_views: '600',
          short_description: 'Educational Q&A channel with $600/month revenue',
          full_description: 'Established educational channel with consistent monthly revenue of $600. Covers various topics in Q&A format with high engagement. Perfect for content creators looking for a profitable channel.',
          status: 'active',
          images: ['https://img.youtube.com/vi/Tt42IVL0aUM/maxresdefault.jpg']
        }
      ];

      for (const listing of listings) {
        const { error } = await supabase
          .from('listings')
          .insert(listing);

        if (error) {
          console.error('Error inserting listing:', error);
          throw error;
        }
      }

      toast({
        title: "Success!",
        description: "2 YouTube channel listings have been added to the marketplace",
      });

      setSeeded(true);
    } catch (error: any) {
      console.error('Error seeding listings:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to seed listings. Please make sure you're logged in as admin.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-orange-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
              <AlertCircle className="w-6 h-6 text-orange-primary" />
              Admin Access Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-center text-muted-foreground">
              You need to be logged in as an admin to add listings.
            </p>
            <Button 
              onClick={() => navigate('/admin/login')}
              className="w-full bg-orange-primary hover:bg-orange-primary/90"
            >
              Go to Admin Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl text-center">Seed YouTube Channel Listings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!seeded ? (
            <>
              <p className="text-center text-muted-foreground">
                This will add 2 YouTube channel listings to your marketplace:
              </p>
              <ul className="list-disc list-inside space-y-2 text-sm">
                <li><strong>The Plot Watcher</strong> - Movies & Music - $499</li>
                <li><strong>Quick Flick</strong> - Educational & QA - $1,249</li>
              </ul>
              <Button 
                onClick={seedListings}
                disabled={loading}
                className="w-full bg-orange-primary hover:bg-orange-primary/90"
                data-testid="button-add-listings"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Adding Listings...
                  </>
                ) : (
                  'Add Listings'
                )}
              </Button>
            </>
          ) : (
            <div className="text-center space-y-4">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              <p className="text-lg font-semibold">Listings Added Successfully!</p>
              <Button 
                onClick={() => navigate('/')}
                className="w-full bg-orange-primary hover:bg-orange-primary/90"
                data-testid="button-view-marketplace"
              >
                View Marketplace
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SeedListings;
