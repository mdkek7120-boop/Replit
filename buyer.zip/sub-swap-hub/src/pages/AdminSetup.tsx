import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CheckCircle, Loader2, Shield, AlertCircle, UserPlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';

interface AdminAccount {
  id: string;
  email: string;
  password: string;
  username: string;
  displayName: string;
}

const AdminSetup = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedAdmin, setSelectedAdmin] = useState<string>('admin1');

  // Multiple admin accounts configuration
  const adminAccounts: AdminAccount[] = [
    {
      id: 'admin1',
      email: 'creditcoinhub@gmail.com',
      password: 'Admin@12345',
      username: 'admin',
      displayName: 'Primary Admin'
    },
    {
      id: 'admin2',
      email: 'mdkek7120@gmail.com',
      password: 'Ra1234567890',
      username: 'admin2',
      displayName: 'Secondary Admin'
    }
  ];

  const getSelectedAdminAccount = (): AdminAccount => {
    return adminAccounts.find(a => a.id === selectedAdmin) || adminAccounts[0];
  };

  const createAdminAccount = async () => {
    setLoading(true);
    setError(null);
    
    const admin = getSelectedAdminAccount();
    
    try {
      console.log(`Step 1: Creating admin account for ${admin.email} in Supabase Auth...`);
      
      // Create admin user in Supabase Auth
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: admin.email,
        password: admin.password,
        options: {
          data: {
            username: admin.username,
            display_name: admin.displayName
          }
        }
      });

      console.log('SignUp result:', signUpData, signUpError);

      if (signUpError) {
        if (signUpError.message.includes('already registered')) {
          console.log('Account exists, checking role...');
          
          // Account exists - just verify it has admin role and redirect to login
          setSuccess(true);
          toast({
            title: "Account Already Exists!",
            description: "This admin account already exists. Please login with your credentials.",
            duration: 5000,
          });
          
          setTimeout(() => navigate('/admin/login'), 2000);
          return;
        }
        throw signUpError;
      }

      if (signUpData.user) {
        console.log('Step 2: Admin user created, ID:', signUpData.user.id);

        // Wait for profile trigger
        await new Promise(resolve => setTimeout(resolve, 1500));

        console.log('Step 3: Creating admin role...');
        
        // Create admin role
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({
            user_id: signUpData.user.id,
            role: 'admin'
          });

        if (roleError && !roleError.message.includes('duplicate')) {
          console.error('Role creation error:', roleError);
          throw new Error('Failed to assign admin role: ' + roleError.message);
        }

        console.log('Step 4: Success! Admin account fully created');

        setSuccess(true);
        toast({
          title: "Success!",
          description: "Admin account created successfully!",
        });

        // Sign out the user so they can log in fresh
        await supabase.auth.signOut();

        setTimeout(() => navigate('/admin/login'), 2000);
      }
    } catch (error: any) {
      console.error('Setup error:', error);
      setError(error.message || 'Failed to create admin account');
      toast({
        title: "Error",
        description: error.message || "Setup failed",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-orange-primary/10 rounded-full">
              <Shield className="h-8 w-8 text-orange-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Admin Setup</CardTitle>
          <CardDescription>
            Create your admin account to access the dashboard
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {!success ? (
            <>
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Select Admin Account to Create:</Label>
                <RadioGroup value={selectedAdmin} onValueChange={setSelectedAdmin}>
                  {adminAccounts.map((admin) => (
                    <div key={admin.id} className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-gray-50">
                      <RadioGroupItem value={admin.id} id={admin.id} />
                      <Label htmlFor={admin.id} className="flex-1 cursor-pointer">
                        <div>
                          <p className="font-semibold text-sm">{admin.displayName}</p>
                          <p className="text-xs text-gray-600">{admin.email}</p>
                        </div>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="text-blue-900">
                  <p className="font-semibold mb-2">Selected Admin Credentials:</p>
                  <p className="text-sm">Email: <strong>{getSelectedAdminAccount().email}</strong></p>
                  <p className="text-sm">Password: <strong>{getSelectedAdminAccount().password}</strong></p>
                </AlertDescription>
              </Alert>
              
              <p className="text-sm text-muted-foreground text-center">
                Click the button below to create the selected admin account. You can then login with the credentials above.
              </p>

              <Button 
                onClick={createAdminAccount}
                disabled={loading}
                className="w-full bg-orange-primary hover:bg-orange-primary/90"
                data-testid="button-setup-admin"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating {getSelectedAdminAccount().displayName}...
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Create {getSelectedAdminAccount().displayName} Account
                  </>
                )}
              </Button>

              <Button 
                onClick={() => navigate('/admin/login')}
                variant="outline"
                className="w-full"
                disabled={loading}
              >
                Already have an account? Login
              </Button>
            </>
          ) : (
            <div className="text-center space-y-4 py-6">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              <p className="text-lg font-semibold">Admin Account Created!</p>
              <p className="text-sm text-muted-foreground">Redirecting to login page...</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminSetup;
