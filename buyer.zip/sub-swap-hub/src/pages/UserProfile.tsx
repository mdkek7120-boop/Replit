import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MessageSquare, 
  Eye, 
  DollarSign, 
  Calendar, 
  User,
  Mail,
  ArrowLeft,
  Youtube,
  Users,
  TrendingUp,
  Clock
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { formatDistanceToNow } from 'date-fns';

interface ProfileData {
  id: string;
  username: string;
  email: string;
  display_name?: string;
  avatar_url?: string;
  created_at: string;
  balance: number;
  is_admin?: boolean;
  is_online?: boolean;
}

interface MessageData {
  id: string;
  content: string;
  message_type: string;
  created_at: string;
  user_type: string;
}

interface ListingData {
  id: string;
  title: string;
  price: number;
  subscriber_count: string;
  average_views: string;
  niche: string;
  status: string;
  images: Json;
}

const UserProfile = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [messages, setMessages] = useState<MessageData[]>([]);
  const [listings, setListings] = useState<ListingData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      loadUserData();
    }
  }, [userId]);

  const loadUserData = async () => {
    try {
      setLoading(true);
      
      // Load user profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (profileError) {
        console.error('Error loading profile:', profileError);
        navigate('/404');
        return;
      }
      
      setProfile({
        ...profileData,
        balance: profileData.balance || 0,
        is_online: true // This would come from presence tracking
      });
      
      // Load user messages
      const { data: messagesData, error: messagesError } = await supabase
        .from('messages')
        .select('id, content, message_type, created_at, user_type')
        .eq('user_contact', profileData.email)
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (!messagesError && messagesData) {
        setMessages(messagesData as MessageData[]);
      }
      
      // Load user listings
      const listingsResult = await supabase
        .from('listings')
        .select('id, title, price, subscriber_count, average_views, niche, status, images')
        .eq('seller_id', userId)
        .eq('status', 'active');
      
      if (!listingsResult.error && listingsResult.data) {
        // Transform the data to match our interface
        const transformedListings: ListingData[] = listingsResult.data.map((listing: any) => ({
          id: listing.id,
          title: listing.title,
          price: listing.price,
          subscriber_count: listing.subscriber_count || '',
          average_views: listing.average_views || '',
          niche: listing.niche || '',
          status: listing.status,
          images: listing.images
        }));
        setListings(transformedListings);
      }
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading user data:', error);
      setLoading(false);
    }
  };

  const handleSendMessage = () => {
    // Navigate to messages with this user's contact
    if (profile) {
      navigate(`/admin/messages?user=${profile.email}`);
    }
  };

  const formatSubscriberCount = (count: string) => {
    const num = parseFloat(count);
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return count;
  };

  const getAvatarFallback = (username: string) => {
    return username ? username.charAt(0).toUpperCase() : 'U';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/80 flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading profile...</div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/80 flex items-center justify-center">
        <Card className="p-8">
          <p className="text-muted-foreground">User not found</p>
          <Button onClick={() => navigate(-1)} className="mt-4">
            <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Back button */}
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>

        {/* Profile Header */}
        <Card className="mb-6 bg-card/95 backdrop-blur border-border/50">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="relative">
                <Avatar className="h-24 w-24 border-4 border-primary/20">
                  <AvatarImage src={profile.avatar_url} alt={profile.username} />
                  <AvatarFallback className="bg-primary/20 text-2xl">
                    {getAvatarFallback(profile.username)}
                  </AvatarFallback>
                </Avatar>
                {profile.is_online && (
                  <div className="absolute bottom-2 right-2 w-4 h-4 bg-green-500 rounded-full border-2 border-background" />
                )}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-bold">{profile.display_name || profile.username}</h1>
                  {profile.is_admin && (
                    <Badge variant="destructive">Admin</Badge>
                  )}
                  {profile.is_online && (
                    <Badge className="bg-green-500/20 text-green-500 border-green-500/30">
                      Online
                    </Badge>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span>@{profile.username}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    <span>{profile.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>Joined {formatDistanceToNow(new Date(profile.created_at))} ago</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-green-500" />
                    <span className="text-lg font-semibold">${profile.balance.toFixed(2)}</span>
                    <span className="text-sm text-muted-foreground">Balance</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <Button onClick={handleSendMessage} className="gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Send Message
                </Button>
                <Button variant="outline" className="gap-2">
                  <Eye className="h-4 w-4" />
                  View Listings
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for Messages and Listings */}
        <Tabs defaultValue="messages" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="messages">
              Message History ({messages.length})
            </TabsTrigger>
            <TabsTrigger value="listings">
              Channel Listings ({listings.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="messages" className="mt-4">
            <Card className="bg-card/95 backdrop-blur border-border/50">
              <CardHeader>
                <CardTitle>Recent Messages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {messages.length > 0 ? (
                    messages.map((msg) => (
                      <div 
                        key={msg.id} 
                        className={`flex gap-3 p-3 rounded-lg ${
                          msg.user_type === 'admin' 
                            ? 'bg-primary/10 ml-auto max-w-[80%]' 
                            : 'bg-secondary/50 mr-auto max-w-[80%]'
                        }`}
                      >
                        <div className="flex-1">
                          <p className="text-sm">{msg.content}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(msg.created_at))} ago
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-muted-foreground py-8">
                      No messages yet
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="listings" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {listings.length > 0 ? (
                listings.map((listing) => (
                  <Card 
                    key={listing.id} 
                    className="bg-card/95 backdrop-blur border-border/50 hover:border-primary/50 transition-all cursor-pointer"
                    onClick={() => navigate(`/listing/${listing.id}`)}
                  >
                    <div className="aspect-video relative overflow-hidden rounded-t-lg">
                      <img 
                        src={
                          Array.isArray(listing.images) && listing.images.length > 0 && typeof listing.images[0] === 'string'
                            ? listing.images[0]
                            : typeof listing.images === 'string' 
                              ? listing.images 
                              : '/placeholder.svg'
                        } 
                        alt={listing.title}
                        className="w-full h-full object-cover"
                      />
                      <Badge className="absolute top-2 right-2">
                        {listing.status}
                      </Badge>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">{listing.title}</h3>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div className="flex items-center gap-2">
                          <Youtube className="h-4 w-4" />
                          <span>{listing.niche}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          <span>{formatSubscriberCount(listing.subscriber_count)} subs</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4" />
                          <span>{listing.average_views} avg views</span>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <DollarSign className="h-4 w-4 text-green-500" />
                          <span className="text-lg font-bold text-green-500">
                            ${listing.price.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="col-span-full bg-card/95 backdrop-blur border-border/50">
                  <CardContent className="p-8">
                    <p className="text-center text-muted-foreground">
                      No active listings
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UserProfile;