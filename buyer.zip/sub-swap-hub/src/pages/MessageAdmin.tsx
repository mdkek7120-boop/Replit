import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ArrowLeft, 
  Send, 
  Paperclip, 
  Mic, 
  Image, 
  User, 
  Clock, 
  MessageSquare, 
  CheckCheck, 
  Check,
  Search,
  MoreVertical
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate, Link } from "react-router-dom";
import { formatDistanceToNow } from 'date-fns';

interface Message {
  id: string;
  message_id: string;
  user_type: string;
  user_contact: string;
  content: string;
  message_type: string;
  file_url?: string;
  transaction_id?: string;
  created_at: string;
  user_profile?: {
    id: string;
    username: string;
    avatar_url?: string;
    is_online?: boolean;
  };
}

interface Conversation {
  user_contact: string;
  user_type: string;
  last_message: string;
  last_message_time: string;
  message_count: number;
  transaction_id?: string;
  unread_count?: number;
  user_profile?: {
    id: string;
    username: string;
    avatar_url?: string;
    is_online?: boolean;
  };
}

const MessageAdmin = () => {
  const navigate = useNavigate();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [replyTo, setReplyTo] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const selectedConversationRef = useRef<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Keep ref in sync with state
  useEffect(() => {
    selectedConversationRef.current = selectedConversation;
  }, [selectedConversation]);

  // Load conversations on mount
  useEffect(() => {
    loadConversations();
    
    // Set up real-time subscription for new messages
    const channel = supabase
      .channel('admin-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages'
        },
        (payload) => {
          // Use the ref instead of state to avoid closure issues
          loadConversations();
          if (selectedConversationRef.current === payload.new.user_contact) {
            loadMessages(selectedConversationRef.current);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []); // Empty dependency array is now safe because we use ref

  // Load messages when conversation is selected
  useEffect(() => {
    if (selectedConversation) {
      loadMessages(selectedConversation);
    }
  }, [selectedConversation]);

  // Auto scroll to bottom when messages update
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadConversations = async () => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('user_contact, user_type, content, created_at, transaction_id')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading conversations:', error);
        return;
      }

      // Group messages by user_contact
      const groupedConversations = data.reduce((acc: { [key: string]: Conversation }, msg) => {
        const key = msg.user_contact;
        if (!acc[key]) {
          acc[key] = {
            user_contact: msg.user_contact,
            user_type: msg.user_type,
            last_message: msg.content,
            last_message_time: msg.created_at,
            message_count: 1,
            transaction_id: msg.transaction_id
          };
        } else {
          acc[key].message_count++;
          // Keep the latest message time
          if (new Date(msg.created_at) > new Date(acc[key].last_message_time)) {
            acc[key].last_message = msg.content;
            acc[key].last_message_time = msg.created_at;
          }
          if (msg.user_type === 'buyer' || msg.user_type === 'seller') {
            acc[key].unread_count = (acc[key].unread_count || 0) + 1;
          }
        }
        return acc;
      }, {});

      // Fetch user profiles for conversations
      const conversationList = Object.values(groupedConversations);
      for (const conv of conversationList) {
        const { data: profileData } = await supabase
          .from('profiles')
          .select('id, username, avatar_url')
          .eq('email', conv.user_contact)
          .single();
        
        if (profileData) {
          conv.user_profile = {
            ...profileData,
            is_online: Math.random() > 0.5 // Mock online status for demo
          };
        }
      }

      setConversations(conversationList);
    } catch (error) {
      console.error('Error loading conversations:', error);
    }
  };

  const loadMessages = async (userContact: string) => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('user_contact', userContact)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error loading messages:', error);
        return;
      }

      setMessages(data || []);
      setReplyTo(userContact);
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const generateMessageId = () => {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `MSG-${timestamp}-${random}`;
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !replyTo) return;
    
    const messageId = generateMessageId();
    
    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          message_id: messageId,
          user_type: 'admin',
          user_contact: replyTo,
          content: newMessage,
          message_type: 'text'
        })
        .select()
        .single();

      if (error) {
        console.error('Error sending message:', error);
        return;
      }

      setMessages(prev => [...prev, data]);
      setNewMessage('');
      loadConversations(); // Refresh conversations list
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !replyTo) return;
    
    const messageId = generateMessageId();
    
    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          message_id: messageId,
          user_type: 'admin',
          user_contact: replyTo,
          content: `Admin uploaded file: ${file.name}`,
          message_type: file.type.startsWith('image/') ? 'image' : 'audio',
          file_url: `uploaded/${file.name}`
        })
        .select()
        .single();

      if (error) {
        console.error('Error uploading file:', error);
        return;
      }

      setMessages(prev => [...prev, data]);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / 60000);
    
    if (diffInMinutes < 1) return "just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hour${Math.floor(diffInMinutes / 60) > 1 ? 's' : ''} ago`;
    if (diffInMinutes < 10080) return `${Math.floor(diffInMinutes / 1440)} day${Math.floor(diffInMinutes / 1440) > 1 ? 's' : ''} ago`;
    return formatDistanceToNow(date, { addSuffix: true });
  };

  const getAvatarFallback = (name: string) => {
    return name ? name.charAt(0).toUpperCase() : 'U';
  };

  const filteredConversations = conversations.filter(conv => 
    conv.user_contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.user_profile?.username?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation Bar */}
      <div className="border-b bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => navigate(-1)}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1 className="text-lg font-semibold">Admin Messages</h1>
          <Badge variant="secondary" className="ml-auto">
            {conversations.length} Chats
          </Badge>
        </div>
      </div>

      <div className="h-[calc(100vh-64px)] flex flex-col md:flex-row">
        {/* Conversations List */}
        <div className={`${selectedConversation ? 'hidden md:flex' : 'flex'} w-full md:w-80 border-r bg-card flex-col`}>
          <div className="p-4 border-b">
            <h2 className="font-semibold text-sm text-muted-foreground">Conversations</h2>
          </div>
          <div className="flex-1 overflow-y-auto">
            {conversations.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-20" />
                <p className="text-sm">No messages yet</p>
              </div>
            ) : (
              conversations.map((conv) => (
                <div
                  key={conv.user_contact}
                  onClick={() => setSelectedConversation(conv.user_contact)}
                  className={`p-4 cursor-pointer hover:bg-muted/50 transition-colors border-b ${
                    selectedConversation === conv.user_contact ? 'bg-muted' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm truncate">{conv.user_contact}</span>
                        <Badge variant="outline" className="text-xs">
                          {conv.user_type}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground truncate mb-1">
                        {conv.last_message}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{formatMessageTime(conv.last_message_time)}</span>
                        {conv.message_count > 1 && (
                          <>
                            <span>•</span>
                            <span>{conv.message_count} msgs</span>
                          </>
                        )}
                      </div>
                      {conv.transaction_id && (
                        <div className="mt-1 text-xs text-primary font-mono">
                          Order: {conv.transaction_id.slice(0, 20)}...
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className={`${selectedConversation ? 'flex' : 'hidden md:flex'} flex-1 flex-col bg-card`}>
          {selectedConversation ? (
            <>
              {/* Chat Header */}
              <div className="border-b p-3 flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedConversation(null)}
                  className="md:hidden"
                >
                  <ArrowLeft className="w-4 h-4" />
                </Button>
                <div className="w-9 h-9 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{selectedConversation}</div>
                  <div className="text-xs text-muted-foreground">
                    {messages.find(m => m.transaction_id)?.transaction_id && (
                      <span className="font-mono">Order: {messages.find(m => m.transaction_id)?.transaction_id}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-muted/10 to-muted/30">
                {messages.map((message, index) => {
                  const showDateDivider = index === 0 || 
                    new Date(message.created_at).toDateString() !== 
                    new Date(messages[index - 1].created_at).toDateString();
                  
                  return (
                    <div key={message.id}>
                      {showDateDivider && (
                        <div className="flex items-center justify-center my-4">
                          <div className="bg-muted/60 text-muted-foreground text-xs px-3 py-1 rounded-full">
                            {new Date(message.created_at).toLocaleDateString('en-US', {
                              weekday: 'short',
                              month: 'short',
                              day: 'numeric'
                            })}
                          </div>
                        </div>
                      )}
                      <div
                        className={`flex ${message.user_type === 'admin' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}
                      >
                        <div className={`max-w-[80%] md:max-w-[70%] px-4 py-2 rounded-2xl shadow-sm ${
                          message.user_type === 'admin'
                            ? 'bg-orange-primary text-white rounded-br-md'
                            : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-bl-md'
                        }`}>
                          {message.transaction_id && (
                            <div className={`text-xs mb-1 font-mono px-2 py-0.5 rounded ${
                              message.user_type === 'admin' 
                                ? 'bg-white/20' 
                                : 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400'
                            }`}>
                              Order: {message.transaction_id.slice(0, 12)}...
                            </div>
                          )}
                          <div className="text-sm whitespace-pre-wrap break-words">
                            {message.content}
                          </div>
                          <div className={`flex items-center gap-1 text-xs mt-1 justify-end ${
                            message.user_type === 'admin' ? 'text-white/80' : 'text-muted-foreground'
                          }`}>
                            <Clock className="w-3 h-3" />
                            <span>{formatMessageTime(message.created_at)}</span>
                            {message.user_type === 'admin' && (
                              <CheckCheck className="w-3.5 h-3.5 ml-0.5" />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Input Area */}
              <div className="border-t p-4 bg-card">
                <div className="flex items-center gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 rounded-full"
                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                    data-testid="input-message"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    size="sm"
                    className="bg-orange-primary hover:bg-orange-primary/90 rounded-full w-10 h-10 p-0"
                    data-testid="button-send"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <MessageSquare className="w-16 h-16 mx-auto mb-3 opacity-20" />
                <p className="text-sm">No conversation selected</p>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />
      <input
        ref={audioInputRef}
        type="file"
        accept="audio/*"
        onChange={handleFileUpload}
        className="hidden"
      />
    </div>
  );
};

export default MessageAdmin;