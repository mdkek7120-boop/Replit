import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { 
  Users, 
  ShoppingCart, 
  DollarSign, 
  TrendingUp,
  Eye,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  MessageSquare,
  Youtube,
  UserCog,
  Search,
  Filter,
  Reply,
  Archive,
  Ban,
  Star,
  Plus
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { UserManagementPanel } from '@/components/UserManagementPanel';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user, isAdmin, loading } = useAuth();
  const { toast } = useToast();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrders: 0,
    totalListings: 0,
    totalRevenue: 0,
    totalMessages: 0,
    unreadMessages: 0
  });
  const [listings, setListings] = useState([]);
  const [orders, setOrders] = useState([]);
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedMessage, setSelectedMessage] = useState<any>(null);
  const [replyText, setReplyText] = useState('');
  const [selectedListing, setSelectedListing] = useState<any>(null);

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      navigate('/admin/login');
      return;
    }

    if (isAdmin) {
      fetchDashboardData();
    }
  }, [user, isAdmin, loading, navigate]);

  const addSampleListings = async () => {
    try {
      const sampleListings = [
        {
          title: 'The Plot Watcher',
          youtube_link: 'https://youtu.be/C9wtDn4ZQdo?si=Xehhth5vvhP1X2tB',
          niche: 'Movies & Music',
          price: 499,
          subscriber_count: '1650',
          average_views: '600',
          short_description: 'Popular movie and music review channel with engaged audience',
          full_description: 'This channel focuses on movie reviews, music analysis, and entertainment content. Great engagement rate with loyal subscriber base. Monetized and ready for immediate transfer.',
          status: 'active',
          images: ['https://img.youtube.com/vi/C9wtDn4ZQdo/maxresdefault.jpg']
        },
        {
          title: 'Quick Flick',
          youtube_link: 'https://youtu.be/Tt42IVL0aUM?si=tMj_gqPvU2abmWgf',
          niche: 'Educational & QA',
          price: 1249,
          subscriber_count: '6610',
          average_views: '600',
          short_description: 'Educational Q&A channel with $600/month revenue',
          full_description: 'Established educational channel with consistent monthly revenue of $600. Covers various topics in Q&A format with high engagement. Perfect for content creators looking for a profitable channel.',
          status: 'active',
          images: ['https://img.youtube.com/vi/Tt42IVL0aUM/maxresdefault.jpg']
        }
      ];

      for (const listing of sampleListings) {
        const { error } = await supabase.from('listings').insert(listing);
        if (error) throw error;
      }

      toast({
        title: "Success!",
        description: "2 sample YouTube channel listings have been added",
      });

      fetchDashboardData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to add sample listings",
        variant: "destructive"
      });
    }
  };

  const fetchDashboardData = async () => {
    try {
      // Fetch stats
      const [usersResult, ordersResult, listingsResult, messagesResult] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact' }),
        supabase.from('orders').select('amount', { count: 'exact' }),
        supabase.from('listings').select('id', { count: 'exact' }),
        supabase.from('messages').select('id, status', { count: 'exact' })
      ]);

      const totalRevenue = ordersResult.data?.reduce((sum, order) => sum + (Number(order.amount) || 0), 0) || 0;
      const unreadMessages = messagesResult.data?.filter(m => m.status === 'active').length || 0;

      setStats({
        totalUsers: usersResult.count || 0,
        totalOrders: ordersResult.count || 0,
        totalListings: listingsResult.count || 0,
        totalRevenue,
        totalMessages: messagesResult.count || 0,
        unreadMessages
      });

      // Fetch recent listings with creator profile
      const { data: listingsData } = await supabase
        .from('listings')
        .select(`
          *,
          profiles:created_by (username, email)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      setListings(listingsData || []);

      // Fetch recent orders
      const { data: ordersData } = await supabase
        .from('orders')
        .select(`
          *,
          listings (title, price)
        `)
        .order('created_at', { ascending: false })
        .limit(10);

      setOrders(ordersData || []);

      // Fetch messages
      const { data: messagesData } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      setMessages(messagesData || []);

      // Fetch users with roles
      const { data: usersData } = await supabase
        .from('profiles')
        .select(`
          *,
          user_roles (role)
        `)
        .order('created_at', { ascending: false });

      setUsers(usersData || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (!error) {
        fetchDashboardData();
      }
    } catch (error) {
      console.error('Error updating order status:', error);
    }
  };

  const updateListingStatus = async (listingId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('listings')
        .update({ status: newStatus })
        .eq('id', listingId);

      if (!error) {
        toast({
          title: "Success",
          description: `Listing ${newStatus === 'active' ? 'approved' : 'updated'}`,
        });
        fetchDashboardData();
      }
    } catch (error) {
      console.error('Error updating listing status:', error);
    }
  };

  const handleReplyToMessage = async () => {
    if (!selectedMessage || !replyText.trim()) return;

    try {
      const { error } = await supabase
        .from('messages')
        .insert({
          transaction_id: selectedMessage.transaction_id,
          user_type: 'admin',
          user_contact: 'admin@ytmarketplace.com',
          content: replyText,
          message_type: 'text',
          message_id: `MSG-${Date.now()}`
        });

      if (!error) {
        toast({
          title: "Reply sent",
          description: "Your message has been sent to the user",
        });
        setReplyText('');
        setSelectedMessage(null);
        fetchDashboardData();
      }
    } catch (error) {
      console.error('Error sending reply:', error);
    }
  };

  const updateMessageStatus = async (messageId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('messages')
        .update({ status: newStatus })
        .eq('id', messageId);

      if (!error) {
        fetchDashboardData();
      }
    } catch (error) {
      console.error('Error updating message status:', error);
    }
  };

  const deleteListing = async (listingId: string) => {
    if (!confirm('Are you sure you want to delete this listing?')) return;

    try {
      const { error } = await supabase
        .from('listings')
        .delete()
        .eq('id', listingId);

      if (!error) {
        toast({
          title: "Listing deleted",
          description: "The listing has been removed",
        });
        fetchDashboardData();
      }
    } catch (error) {
      console.error('Error deleting listing:', error);
    }
  };

  const banUser = async (userId: string) => {
    if (!confirm('Are you sure you want to ban this user?')) return;

    try {
      // Add ban logic here - could update a 'banned' field in profiles
      toast({
        title: "User banned",
        description: "The user has been banned from the platform",
      });
      fetchDashboardData();
    } catch (error) {
      console.error('Error banning user:', error);
    }
  };

  const filteredMessages = messages.filter((msg: any) => {
    const matchesSearch = msg.content?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         msg.user_contact?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || msg.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredListings = listings.filter((listing: any) => {
    const matchesSearch = listing.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         listing.youtube_link?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || listing.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Admin Dashboard</h1>
              <p className="text-muted-foreground">Manage your YouTube marketplace</p>
            </div>
            <div className="flex gap-2">
              {stats.totalListings === 0 && (
                <Button 
                  onClick={addSampleListings}
                  className="bg-purple-600 hover:bg-purple-700"
                  data-testid="button-add-sample-data"
                >
                  <Youtube className="w-4 h-4 mr-2" />
                  Add Sample Channels
                </Button>
              )}
              <Button 
                onClick={() => navigate('/admin/create-listing')}
                className="bg-green-600 hover:bg-green-700"
                data-testid="button-create-listing"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Listing
              </Button>
              <Button 
                variant="default"
                onClick={() => navigate('/admin/messages')}
                className="bg-orange-primary hover:bg-orange-primary/90"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Admin Messages
                {stats.unreadMessages > 0 && (
                  <Badge className="ml-2 bg-red-500 text-white">
                    {stats.unreadMessages}
                  </Badge>
                )}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => navigate('/')}
              >
                Back to Site
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalOrders}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Listings</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalListings}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${stats.totalRevenue.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Messages</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalMessages}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unread</CardTitle>
              <MessageSquare className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-500">{stats.unreadMessages}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="messages" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="messages">
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="listings">
              <Youtube className="h-4 w-4 mr-2" />
              Listings Review
            </TabsTrigger>
            <TabsTrigger value="orders">
              <ShoppingCart className="h-4 w-4 mr-2" />
              Orders
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="h-4 w-4 mr-2" />
              User Management
            </TabsTrigger>
            <TabsTrigger value="management">
              <TrendingUp className="h-4 w-4 mr-2" />
              Management
            </TabsTrigger>
          </TabsList>

          {/* Messages Management Tab */}
          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Message Inbox</CardTitle>
                    <CardDescription>View and respond to user messages</CardDescription>
                  </div>
                  <Badge variant="secondary">{stats.unreadMessages} Unread</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Search and Filter */}
                  <div className="flex gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search messages..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Messages</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Messages List */}
                  <div className="space-y-3">
                    {filteredMessages.map((message: any) => (
                      <div key={message.id} className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-muted/50">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={message.user_type === 'admin' ? 'default' : 'secondary'}>
                              {message.user_type}
                            </Badge>
                            <span className="text-sm text-muted-foreground">{message.user_contact}</span>
                            {message.transaction_id && (
                              <Badge variant="outline" className="text-xs">
                                {message.transaction_id}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm mb-2">{message.content}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>{new Date(message.created_at).toLocaleString()}</span>
                            {message.message_type !== 'text' && (
                              <Badge variant="outline" className="text-xs">
                                {message.message_type}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setSelectedMessage(message)}
                              >
                                <Reply className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Reply to Message</DialogTitle>
                                <DialogDescription>
                                  Send a reply to {message.user_contact}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="p-3 bg-muted rounded-lg">
                                  <p className="text-sm">{message.content}</p>
                                </div>
                                <Textarea
                                  placeholder="Type your reply..."
                                  value={replyText}
                                  onChange={(e) => setReplyText(e.target.value)}
                                  rows={4}
                                />
                              </div>
                              <DialogFooter>
                                <Button onClick={handleReplyToMessage}>
                                  Send Reply
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateMessageStatus(message.id, message.status === 'active' ? 'archived' : 'active')}
                          >
                            <Archive className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Listings Review Tab */}
          <TabsContent value="listings">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>YouTube Listings Review</CardTitle>
                    <CardDescription>Review and approve channel listings</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Search and Filter */}
                  <div className="flex gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search listings..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Listings</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Listings List */}
                  <div className="space-y-4">
                    {filteredListings.map((listing: any) => (
                      <div key={listing.id} className="p-4 border border-border rounded-lg">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{listing.title}</h3>
                              <Badge variant={listing.status === 'active' ? 'default' : listing.status === 'pending' ? 'secondary' : 'outline'}>
                                {listing.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              Created by: {listing.profiles?.username || listing.profiles?.email || 'Unknown'}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-primary">${listing.price}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Subscribers</p>
                            <p className="font-medium">{listing.subscriber_count || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Avg Views</p>
                            <p className="font-medium">{listing.average_views || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Niche</p>
                            <p className="font-medium">{listing.niche || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Created</p>
                            <p className="font-medium">{new Date(listing.created_at).toLocaleDateString()}</p>
                          </div>
                        </div>

                        {listing.youtube_link && (
                          <div className="mb-4">
                            <p className="text-sm text-muted-foreground mb-1">YouTube Link</p>
                            <a 
                              href={listing.youtube_link} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-sm text-primary hover:underline"
                            >
                              {listing.youtube_link}
                            </a>
                          </div>
                        )}

                        {listing.short_description && (
                          <div className="mb-4">
                            <p className="text-sm text-muted-foreground mb-1">Description</p>
                            <p className="text-sm">{listing.short_description}</p>
                          </div>
                        )}

                        {listing.images && listing.images.length > 0 && (
                          <div className="mb-4">
                            <p className="text-sm text-muted-foreground mb-2">Screenshots ({listing.images.length})</p>
                            <div className="flex gap-2 flex-wrap">
                              {listing.images.slice(0, 4).map((img: string, idx: number) => (
                                <div key={idx} className="w-20 h-20 border rounded overflow-hidden">
                                  <img src={img} alt={`Screenshot ${idx + 1}`} className="w-full h-full object-cover" />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="flex gap-2 pt-4 border-t">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setSelectedListing(listing)}
                              >
                                <Eye className="h-4 w-4 mr-2" />
                                View Full Details
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>{listing.title}</DialogTitle>
                                <DialogDescription>
                                  Complete listing details
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-sm font-medium">Price</p>
                                    <p className="text-2xl font-bold">${listing.price}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium">Status</p>
                                    <Badge>{listing.status}</Badge>
                                  </div>
                                </div>
                                <div>
                                  <p className="text-sm font-medium mb-2">Full Description</p>
                                  <p className="text-sm">{listing.full_description || listing.short_description || 'No description provided'}</p>
                                </div>
                                {listing.images && listing.images.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium mb-2">All Screenshots</p>
                                    <div className="grid grid-cols-2 gap-2">
                                      {listing.images.map((img: string, idx: number) => (
                                        <img key={idx} src={img} alt={`Screenshot ${idx + 1}`} className="w-full rounded border" />
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          {listing.status !== 'active' && (
                            <Button 
                              size="sm"
                              onClick={() => updateListingStatus(listing.id, 'active')}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Approve
                            </Button>
                          )}
                          
                          {listing.status === 'active' && (
                            <Button 
                              size="sm"
                              variant="outline"
                              onClick={() => updateListingStatus(listing.id, 'inactive')}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Deactivate
                            </Button>
                          )}

                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={() => updateListingStatus(listing.id, 'pending')}
                          >
                            <Clock className="h-4 w-4 mr-2" />
                            Set Pending
                          </Button>

                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              // Mark as featured - could add a 'featured' field
                              toast({
                                title: "Feature updated",
                                description: "Listing marked as featured",
                              });
                            }}
                          >
                            <Star className="h-4 w-4 mr-2" />
                            Featured
                          </Button>

                          <Button 
                            size="sm"
                            variant="destructive"
                            onClick={() => deleteListing(listing.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Recent Orders</CardTitle>
                <CardDescription>Manage customer orders</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {orders.map((order: any) => (
                    <div key={order.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex-1">
                        <h3 className="font-semibold">{order.order_id}</h3>
                        <p className="text-sm text-muted-foreground">
                          {order.listings?.title} - ${order.amount}
                        </p>
                        <p className="text-xs text-muted-foreground">{order.buyer_email}</p>
                        <Badge 
                          variant={
                            order.status === 'completed' ? 'default' : 
                            order.status === 'pending' ? 'secondary' : 'outline'
                          }
                        >
                          {order.status}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => updateOrderStatus(order.id, 'completed')}
                          disabled={order.status === 'completed'}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => updateOrderStatus(order.id, 'pending')}
                          disabled={order.status === 'pending'}
                        >
                          <Clock className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Management Tab */}
          <TabsContent value="users">
            <UserManagementPanel />
          </TabsContent>

          {/* Management Tab */}
          <TabsContent value="management">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Management</CardTitle>
                <CardDescription>Bulk actions and advanced controls</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Bulk Actions</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button variant="outline" className="justify-start">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Approve Multiple Listings
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <Archive className="h-4 w-4 mr-2" />
                        Archive Old Messages
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <Star className="h-4 w-4 mr-2" />
                        Mark Featured Channels
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Clean Up Inactive Listings
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Action Logs</h3>
                    <div className="p-4 border rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        Action logging feature - Track all admin actions including approvals, bans, and modifications
                      </p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Message Templates</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start text-left">
                        <Reply className="h-4 w-4 mr-2" />
                        Welcome Template: "Thank you for listing your channel..."
                      </Button>
                      <Button variant="outline" className="w-full justify-start text-left">
                        <Reply className="h-4 w-4 mr-2" />
                        Approval Template: "Your listing has been approved..."
                      </Button>
                      <Button variant="outline" className="w-full justify-start text-left">
                        <Reply className="h-4 w-4 mr-2" />
                        Rejection Template: "We need more information..."
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;