import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import SellChannel from "./pages/SellChannel";
import SellConfirmation from "./pages/SellConfirmation";
import Messages from "./pages/Messages";
import MessageAdmin from "./pages/MessageAdmin";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogin from "./pages/AdminLogin";
import ListingDetails from "./pages/ListingDetails";
import CreateListing from "./pages/CreateListing";
import SeedListings from "./pages/SeedListings";
import AdminSetup from "./pages/AdminSetup";
import NotFound from "./pages/NotFound";
import UserProfile from "./pages/UserProfile";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/sell" element={<SellChannel />} />
          <Route path="/sell-confirmation" element={<SellConfirmation />} />
          <Route path="/listing/:id" element={<ListingDetails />} />
          <Route path="/messages/:transactionId" element={<Messages />} />
          <Route path="/admin/messages" element={<MessageAdmin />} />
          <Route path="/admin/setup" element={<AdminSetup />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/create-listing" element={<CreateListing />} />
          <Route path="/admin" element={<Navigate to="/admin/login" replace />} />
          <Route path="/seed-listings" element={<SeedListings />} />
          <Route path="/profile/:userId" element={<UserProfile />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
