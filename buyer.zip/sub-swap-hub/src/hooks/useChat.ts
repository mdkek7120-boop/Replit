import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface ChatMessage {
  id: string;
  message_id: string;
  sender: 'user' | 'admin';
  content: string;
  message_type: 'text' | 'image' | 'audio';
  file_url?: string;
  timestamp: Date;
  user_contact?: string;
  user_type?: string;
  conversation_id?: string;
}

const STORAGE_KEY = 'ytmarket_chat_messages';
const CONVERSATION_KEY = 'ytmarket_conversation_id';

export const useChat = (isLoggedIn: boolean = false, userEmail?: string) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationId, setConversationId] = useState<string>('');
  const { toast } = useToast();

  // Generate conversation ID
  const generateConversationId = useCallback(() => {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `CONV-${timestamp}-${random}`;
  }, []);

  // Initialize conversation
  useEffect(() => {
    const initConversation = () => {
      let convId = localStorage.getItem(CONVERSATION_KEY);
      if (!convId) {
        convId = generateConversationId();
        localStorage.setItem(CONVERSATION_KEY, convId);
      }
      setConversationId(convId);
    };

    initConversation();
  }, [generateConversationId]);

  // Load messages on mount
  useEffect(() => {
    const loadMessages = async () => {
      if (isLoggedIn && userEmail && conversationId) {
        // Load from database for logged-in users
        try {
          const { data, error } = await supabase
            .from('messages')
            .select('*')
            .eq('user_contact', userEmail)
            .order('created_at', { ascending: true });

          if (error) {
            console.error('Error loading messages:', error);
            return;
          }

          const formattedMessages: ChatMessage[] = data.map(msg => ({
            id: msg.id,
            message_id: msg.message_id,
            sender: msg.user_type === 'admin' ? 'admin' : 'user',
            content: msg.content,
            message_type: msg.message_type as 'text' | 'image' | 'audio',
            file_url: msg.file_url,
            timestamp: new Date(msg.created_at),
            user_contact: msg.user_contact,
            user_type: msg.user_type,
            conversation_id: conversationId
          }));

          setMessages(formattedMessages);
        } catch (error) {
          console.error('Error loading messages:', error);
        }
      } else {
        // Load from localStorage for non-logged-in users
        const stored = localStorage.getItem(`${STORAGE_KEY}_${conversationId}`);
        if (stored) {
          try {
            const parsed = JSON.parse(stored);
            const formattedMessages = parsed.map((msg: any) => ({
              ...msg,
              timestamp: new Date(msg.timestamp)
            }));
            setMessages(formattedMessages);
          } catch (error) {
            console.error('Error parsing stored messages:', error);
          }
        }
      }
    };

    if (conversationId) {
      loadMessages();
    }
  }, [isLoggedIn, userEmail, conversationId]);

  // Save to localStorage for non-logged-in users
  const saveToLocalStorage = useCallback((msgs: ChatMessage[]) => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_${conversationId}`, JSON.stringify(msgs));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  }, [conversationId]);

  // Send message function
  const sendMessage = useCallback(async (
    content: string,
    type: 'text' | 'image' | 'audio' = 'text',
    file?: File,
    userContact?: string,
    userType: 'buyer' | 'seller' = 'buyer'
  ) => {
    const messageId = `MSG-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const timestamp = new Date();

    const newMessage: ChatMessage = {
      id: messageId,
      message_id: messageId,
      sender: 'user',
      content,
      message_type: type,
      timestamp,
      user_contact: userContact || 'anonymous',
      user_type: userType,
      conversation_id: conversationId,
      file_url: file ? `uploaded/${file.name}` : undefined
    };

    // Add to local state immediately
    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);

    if (isLoggedIn && userEmail) {
      // Save to database for logged-in users
      try {
        const { error } = await supabase
          .from('messages')
          .insert({
            message_id: messageId,
            user_type: userType,
            user_contact: userEmail,
            content,
            message_type: type,
            file_url: file ? `uploaded/${file.name}` : null,
            transaction_id: conversationId
          });

        if (error) {
          console.error('Error saving to database:', error);
          toast({
            title: "Error",
            description: "Failed to save message to server",
            variant: "destructive"
          });
          return false;
        }
      } catch (error) {
        console.error('Database error:', error);
        return false;
      }
    } else {
      // Save to localStorage for anonymous users
      saveToLocalStorage(updatedMessages);
    }

    return true;
  }, [messages, isLoggedIn, userEmail, conversationId, saveToLocalStorage, toast]);

  // Sync anonymous messages to database when user logs in
  const syncAnonymousMessages = useCallback(async (email: string) => {
    if (!conversationId) return;

    const stored = localStorage.getItem(`${STORAGE_KEY}_${conversationId}`);
    if (!stored) return;

    try {
      const anonymousMessages = JSON.parse(stored);
      
      for (const msg of anonymousMessages) {
        if (msg.sender === 'user') {
          await supabase
            .from('messages')
            .insert({
              message_id: msg.message_id,
              user_type: msg.user_type || 'buyer',
              user_contact: email,
              content: msg.content,
              message_type: msg.message_type,
              file_url: msg.file_url,
              transaction_id: conversationId
            });
        }
      }

      // Clear localStorage after sync
      localStorage.removeItem(`${STORAGE_KEY}_${conversationId}`);
    } catch (error) {
      console.error('Error syncing anonymous messages:', error);
    }
  }, [conversationId]);

  // Subscribe to real-time updates for logged-in users
  useEffect(() => {
    if (!isLoggedIn || !userEmail || !conversationId) return;

    const channel = supabase
      .channel('chat-updates')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `user_contact=eq.${userEmail}`
        },
        (payload) => {
          const newMsg = payload.new;
          const chatMessage: ChatMessage = {
            id: newMsg.id,
            message_id: newMsg.message_id,
            sender: newMsg.user_type === 'admin' ? 'admin' : 'user',
            content: newMsg.content,
            message_type: newMsg.message_type,
            file_url: newMsg.file_url,
            timestamp: new Date(newMsg.created_at),
            user_contact: newMsg.user_contact,
            user_type: newMsg.user_type,
            conversation_id: conversationId
          };

          setMessages(prev => {
            // Avoid duplicates
            if (prev.find(msg => msg.message_id === chatMessage.message_id)) {
              return prev;
            }
            return [...prev, chatMessage];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isLoggedIn, userEmail, conversationId]);

  return {
    messages,
    conversationId,
    sendMessage,
    syncAnonymousMessages
  };
};