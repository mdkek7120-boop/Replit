import { useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export interface AuthState {
  user: User | null;
  session: Session | null;
  profile: any;
  userRole: string | null;
  isAdmin: boolean;
  loading: boolean;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    session: null,
    profile: null,
    userRole: null,
    isAdmin: false,
    loading: true
  });

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        const user = session?.user ?? null;
        
        if (user) {
          // Fetch profile and role
          setTimeout(async () => {
            try {
              const [profileResult, roleResult] = await Promise.all([
                supabase
                  .from('profiles')
                  .select('*')
                  .eq('user_id', user.id)
                  .single(),
                supabase
                  .from('user_roles')
                  .select('role')
                  .eq('user_id', user.id)
                  .single()
              ]);

              setAuthState({
                user,
                session,
                profile: profileResult.data,
                userRole: roleResult.data?.role || null,
                isAdmin: roleResult.data?.role === 'admin',
                loading: false
              });
            } catch (error) {
              console.error('Error fetching user data:', error);
              setAuthState({
                user,
                session,
                profile: null,
                userRole: null,
                isAdmin: false,
                loading: false
              });
            }
          }, 0);
        } else {
          setAuthState({
            user: null,
            session: null,
            profile: null,
            userRole: null,
            isAdmin: false,
            loading: false
          });
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        const user = session.user;
        
        setTimeout(async () => {
          try {
            const [profileResult, roleResult] = await Promise.all([
              supabase
                .from('profiles')
                .select('*')
                .eq('user_id', user.id)
                .single(),
              supabase
                .from('user_roles')
                .select('role')
                .eq('user_id', user.id)
                .single()
            ]);

            setAuthState({
              user,
              session,
              profile: profileResult.data,
              userRole: roleResult.data?.role || null,
              isAdmin: roleResult.data?.role === 'admin',
              loading: false
            });
          } catch (error) {
            console.error('Error fetching user data:', error);
            setAuthState({
              user,
              session,
              profile: null,
              userRole: null,
              isAdmin: false,
              loading: false
            });
          }
        }, 0);
      } else {
        setAuthState({
          user: null,
          session: null,
          profile: null,
          userRole: null,
          isAdmin: false,
          loading: false
        });
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return { ...authState, signOut };
};