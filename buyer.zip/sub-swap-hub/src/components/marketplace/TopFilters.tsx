import { useState } from "react";
import { SlidersHorizontal, X, Grid3X3, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useAuth } from "@/hooks/useAuth";
import { UserProfileDialog } from "@/components/UserProfileDialog";

interface TopFiltersProps {
  onViewChange?: (view: "grid" | "list") => void;
  currentView?: "grid" | "list";
}

export const TopFilters = ({ onViewChange, currentView = "grid" }: TopFiltersProps) => {
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState([1000, 50000]);
  const [selectedSubscribers, setSelectedSubscribers] = useState<string[]>([]);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState("relevance");
  const { user, profile } = useAuth();

  const subscriberRanges = [
    { label: "1K - 10K", count: 234, value: "1k-10k" },
    { label: "10K - 50K", count: 156, value: "10k-50k" },
    { label: "50K - 100K", count: 89, value: "50k-100k" },
    { label: "100K - 500K", count: 67, value: "100k-500k" },
    { label: "500K+", count: 23, value: "500k+" }
  ];

  const features = [
    { label: "Verified Channel", count: 145, value: "verified" },
    { label: "Monetized", count: 267, value: "monetized" },
    { label: "Regular Uploads", count: 189, value: "regular-uploads" },
    { label: "High Engagement", count: 123, value: "high-engagement" }
  ];

  const handleSubscriberChange = (value: string, checked: boolean) => {
    if (checked) {
      setSelectedSubscribers([...selectedSubscribers, value]);
    } else {
      setSelectedSubscribers(selectedSubscribers.filter(item => item !== value));
    }
  };

  const handleFeatureChange = (value: string, checked: boolean) => {
    if (checked) {
      setSelectedFeatures([...selectedFeatures, value]);
    } else {
      setSelectedFeatures(selectedFeatures.filter(item => item !== value));
    }
  };

  const clearAllFilters = () => {
    setPriceRange([1000, 50000]);
    setSelectedSubscribers([]);
    setSelectedFeatures([]);
    setSortBy("relevance");
  };

  const hasActiveFilters = 
    priceRange[0] !== 1000 || priceRange[1] !== 50000 ||
    selectedSubscribers.length > 0 || selectedFeatures.length > 0 ||
    sortBy !== "relevance";

  return (
    <div className="bg-card border-b border-border">
      <div className="container mx-auto px-4 py-4">
        {/* Main Controls Row */}
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
          {/* Left Side - Filter Toggle and Profile */}
          <div className="flex flex-1 gap-3 items-center w-full lg:w-auto">
            {/* Filter Toggle */}
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filters
              {hasActiveFilters && (
                <span className="bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">
                  •
                </span>
              )}
            </Button>

            {/* Profile Button - Only visible when logged in */}
            {user && profile && (
              <UserProfileDialog user={user} profile={profile} />
            )}

            {/* Clear Filters */}
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllFilters}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4 mr-1" />
                Clear
              </Button>
            )}
          </div>

          {/* Right Side - Sort and View Toggle */}
          <div className="flex items-center gap-3">
            {/* Sort Dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground hidden sm:block">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevance</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="subscribers">Most Subscribers</SelectItem>
                  <SelectItem value="engagement">High Engagement</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* View Toggle */}
            <div className="flex items-center border border-border rounded-md">
              <Button
                variant={currentView === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange?.("grid")}
                className="rounded-r-none"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={currentView === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange?.("list")}
                className="rounded-l-none border-l"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Expandable Filters Section */}
        <Collapsible open={showFilters} onOpenChange={setShowFilters}>
          <CollapsibleContent className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4 bg-muted/30 rounded-lg">
              {/* Price Range */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Price Range</Label>
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={100000}
                  min={0}
                  step={1000}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>${priceRange[0].toLocaleString()}</span>
                  <span>${priceRange[1].toLocaleString()}+</span>
                </div>
              </div>

              {/* Subscribers */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Subscribers</Label>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {subscriberRanges.map((range) => (
                    <div key={range.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={range.value}
                        checked={selectedSubscribers.includes(range.value)}
                        onCheckedChange={(checked) => handleSubscriberChange(range.value, checked as boolean)}
                      />
                      <Label htmlFor={range.value} className="text-sm flex-1 cursor-pointer">
                        {range.label}
                      </Label>
                      <span className="text-xs text-muted-foreground">({range.count})</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Features */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Features</Label>
                <div className="space-y-2">
                  {features.map((feature) => (
                    <div key={feature.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={feature.value}
                        checked={selectedFeatures.includes(feature.value)}
                        onCheckedChange={(checked) => handleFeatureChange(feature.value, checked as boolean)}
                      />
                      <Label htmlFor={feature.value} className="text-sm flex-1 cursor-pointer">
                        {feature.label}
                      </Label>
                      <span className="text-xs text-muted-foreground">({feature.count})</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </div>
  );
};