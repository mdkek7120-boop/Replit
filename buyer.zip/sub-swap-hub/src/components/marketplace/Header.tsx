import { User, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import ytMarketLogo from "@/assets/yt-market-logo.png";

export const Header = () => {
  const navigate = useNavigate();
  const { user, profile, isAdmin, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
            <img src={ytMarketLogo} alt="YT Market" className="w-10 h-10 rounded-lg" />
            <span className="font-bold text-xl text-gray-900">YT Market</span>
          </div>

          {/* Right Side - Auth */}
          <div className="flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                {isAdmin && (
                  <Button 
                    onClick={() => navigate('/admin/dashboard')}
                    variant="outline"
                    size="sm"
                    className="text-orange-primary border-orange-primary hover:bg-orange-primary hover:text-white"
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Admin Panel
                  </Button>
                )}
                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg">
                  <User className="h-4 w-4 text-gray-600" />
                  <span className="text-sm font-medium text-gray-900">
                    {profile?.username || user.email}
                  </span>
                  {isAdmin && (
                    <span className="text-xs bg-orange-primary text-white px-2 py-1 rounded">
                      Admin
                    </span>
                  )}
                </div>
              </div>
            ) : (
              <Button 
                onClick={() => navigate('/auth')}
                className="bg-orange-primary hover:bg-orange-primary/90 text-white"
                size="sm"
              >
                Login / Sign Up
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};