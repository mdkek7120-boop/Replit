import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

export const FilterSidebar = () => {
  return (
    <div className="space-y-4">
      {/* Price Range */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Price Range</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Slider
            defaultValue={[1000, 50000]}
            max={100000}
            min={0}
            step={1000}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>$0</span>
            <span>$100K+</span>
          </div>
        </CardContent>
      </Card>

      {/* Subscriber Count */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Subscribers</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {[
            { label: "1K - 10K", count: 234 },
            { label: "10K - 50K", count: 156 },
            { label: "50K - 100K", count: 89 },
            { label: "100K - 500K", count: 67 },
            { label: "500K+", count: 23 }
          ].map((range) => (
            <div key={range.label} className="flex items-center space-x-2">
              <Checkbox id={range.label} />
              <Label htmlFor={range.label} className="text-sm flex-1">
                {range.label}
              </Label>
              <span className="text-xs text-muted-foreground">({range.count})</span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Channel Features */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Features</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {[
            { label: "Verified Channel", count: 145 },
            { label: "Monetized", count: 267 },
            { label: "Regular Uploads", count: 189 },
            { label: "High Engagement", count: 123 }
          ].map((feature) => (
            <div key={feature.label} className="flex items-center space-x-2">
              <Checkbox id={feature.label} />
              <Label htmlFor={feature.label} className="text-sm flex-1">
                {feature.label}
              </Label>
              <span className="text-xs text-muted-foreground">({feature.count})</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};