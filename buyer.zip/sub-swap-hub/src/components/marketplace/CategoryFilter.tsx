import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronUp } from "lucide-react";

const categories = [
  { name: "All Categories", count: 569, value: "all" },
  { name: "Gaming", count: 123, value: "gaming" },
  { name: "Music", count: 89, value: "music" },
  { name: "Technology", count: 67, value: "technology" },
  { name: "Education", count: 56, value: "education" },
  { name: "Entertainment", count: 45, value: "entertainment" },
  { name: "Food & Cooking", count: 34, value: "food" },
  { name: "Fitness & Health", count: 28, value: "fitness" },
  { name: "Fashion & Style", count: 23, value: "fashion" },
  { name: "Travel", count: 19, value: "travel" },
  { name: "Pets & Animals", count: 15, value: "pets" },
  { name: "Comedy", count: 12, value: "comedy" }
];

interface CategoryFilterProps {
  selectedCategory?: string;
  onCategoryChange?: (category: string) => void;
}

export const CategoryFilter = ({ selectedCategory = "all", onCategoryChange }: CategoryFilterProps) => {
  const [showAll, setShowAll] = useState(false);
  const displayCategories = showAll ? categories : categories.slice(0, 6);

  return (
    <div className="bg-card border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-wrap gap-2 items-center">
          {displayCategories.map((category) => (
            <Button
              key={category.value}
              variant={selectedCategory === category.value ? "default" : "outline"}
              size="sm"
              onClick={() => onCategoryChange?.(category.value)}
              className={`flex items-center gap-2 ${
                selectedCategory === category.value
                  ? "bg-orange-primary hover:bg-orange-primary/90 text-white"
                  : "hover:bg-orange-primary/10 hover:text-orange-primary"
              }`}
            >
              {category.name}
              <Badge 
                variant="secondary" 
                className={`text-xs ${
                  selectedCategory === category.value
                    ? "bg-white/20 text-white"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {category.count}
              </Badge>
            </Button>
          ))}
          
          {categories.length > 6 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAll(!showAll)}
              className="flex items-center gap-1 text-muted-foreground hover:text-foreground"
            >
              {showAll ? (
                <>
                  Show Less <ChevronUp className="h-4 w-4" />
                </>
              ) : (
                <>
                  Show More <ChevronDown className="h-4 w-4" />
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};