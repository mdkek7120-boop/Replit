import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Users, DollarSign, Crown, CheckCircle, Star, Check } from "lucide-react";

interface ChannelCardProps {
  channel: {
    id: string;
    title: string;
    category: string;
    price: number;
    subscribers: string;
    monthlyIncome: string;
    thumbnail: string;
    verified: boolean;
    featured: boolean;
    badges: string[];
    sellerRating: number;
    isPremium?: boolean;
    isVip?: boolean;
  };
  viewMode?: "grid" | "list";
}

export const ChannelCard = ({ channel, viewMode = "grid" }: ChannelCardProps) => {
  if (viewMode === "list") {
    return (
      <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 bg-card">
        <div className="flex">
          <div className="relative w-48 flex-shrink-0">
            <img
              src={channel.thumbnail}
              alt={channel.title}
              className="w-full h-32 object-cover"
            />
            
            {/* Premium Badge Overlay */}
            <div className="absolute top-2 left-2 flex flex-wrap gap-1">
              {channel.badges.map((badge) => (
                <Badge
                  key={badge}
                  variant={badge === "VIP" ? "default" : badge === "PRO" ? "secondary" : "outline"}
                  className={`text-xs font-semibold ${
                    badge === "VIP"
                      ? "bg-orange-primary text-white"
                      : badge === "PRO"
                      ? "bg-purple-600 text-white"
                      : "bg-green-600 text-white"
                  }`}
                >
                  {badge}
                </Badge>
              ))}
            </div>

            {/* Verified Badge */}
            {channel.verified && (
              <div className="absolute top-2 right-2">
                <Badge variant="outline" className="bg-white/90 text-blue-600 border-blue-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Verified
                </Badge>
              </div>
            )}
          </div>

          <CardContent className="flex-1 p-4 flex justify-between">
            <div className="space-y-2">
              <div>
                <h3 className="font-semibold text-lg text-foreground mb-1">{channel.title}</h3>
                <p className="text-sm text-muted-foreground">{channel.category}</p>
              </div>

              <div className="flex gap-6 text-sm">
                <div>
                  <span className="text-muted-foreground">Subscribers: </span>
                  <span className="font-semibold text-foreground">{channel.subscribers}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Monthly Income: </span>
                  <span className="font-semibold text-green-600">{channel.monthlyIncome}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{channel.sellerRating}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-end justify-between">
              <div className="text-right">
                <span className="text-2xl font-bold text-orange-primary">${channel.price.toLocaleString()}</span>
              </div>
              <Button 
                className="bg-orange-primary hover:bg-orange-primary/90 text-white"
                onClick={() => window.location.href = `/listing/${channel.id}`}
              >
                View Details
              </Button>
            </div>
          </CardContent>
        </div>
      </Card>
    );
  }

  // Grid view - modern dark theme design
  const formatSubscribers = (subs: string) => {
    const num = parseFloat(subs.replace(/[^\d.]/g, ''));
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return subs;
  };

  return (
    <Card className="group overflow-hidden hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 bg-card/90 backdrop-blur border border-border/50 hover:border-primary/50">
      <div className="relative aspect-video">
        <img
          src={channel.thumbnail}
          alt={channel.title}
          className="w-full h-full object-cover"
        />
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
        
        {/* Top badges */}
        <div className="absolute top-3 left-3 flex items-center gap-2">
          {channel.isPremium !== false && (
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold px-3 py-1 text-xs shadow-lg">
              <Crown className="w-3 h-3 mr-1" />
              PREMIUM
            </Badge>
          )}
          {channel.verified && (
            <Badge className="bg-primary/90 backdrop-blur text-primary-foreground font-semibold px-2 py-1 text-xs">
              <CheckCircle className="w-3 h-3 mr-1" />
              Verified
            </Badge>
          )}
        </div>

        {/* Monetization status */}
        {channel.badges?.includes("MONETIZED") && (
          <div className="absolute top-3 right-3">
            <div className="bg-green-500/90 backdrop-blur rounded-full px-3 py-1 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-white" />
              <span className="text-white font-bold text-xs">MONETIZED</span>
            </div>
          </div>
        )}

        {/* Title overlay at bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="font-bold text-lg text-white drop-shadow-lg line-clamp-2">
            {channel.title}
          </h3>
        </div>
      </div>

      <CardContent className="p-4 space-y-3">
        {/* Category */}
        <div className="flex items-center justify-between">
          <Badge variant="secondary" className="text-xs">
            {channel.category}
          </Badge>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-semibold">{channel.sellerRating || 4.8}</span>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 py-2">
          <div>
            <p className="text-xs text-muted-foreground">Subscribers</p>
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4 text-primary" />
              <span className="font-bold text-foreground">
                {formatSubscribers(channel.subscribers)}
              </span>
            </div>
          </div>
          {channel.monthlyIncome && channel.monthlyIncome !== "$0" && (
            <div>
              <p className="text-xs text-muted-foreground">Monthly</p>
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4 text-green-500" />
                <span className="font-bold text-green-500">
                  {channel.monthlyIncome}
                </span>
              </div>
            </div>
          )}
        </div>
        
        {/* Price and action */}
        <div className="pt-2 border-t border-border/50">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs text-muted-foreground">Price</span>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              ${channel.price.toLocaleString()}
            </span>
          </div>
          
          <Button 
            className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white font-semibold shadow-lg"
            onClick={() => window.location.href = `/listing/${channel.id}`}
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
