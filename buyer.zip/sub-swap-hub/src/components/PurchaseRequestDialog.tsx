import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle2 } from 'lucide-react';

interface PurchaseRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  listing: any;
}

export function PurchaseRequestDialog({ open, onOpenChange, listing }: PurchaseRequestDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    buyerEmail: '',
    buyerContact: '',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const messageId = `MSG-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Create order record
      const { error: orderError } = await supabase
        .from('orders')
        .insert({
          order_id: transactionId,
          listing_id: listing.id,
          buyer_id: user?.id || null,
          buyer_email: formData.buyerEmail,
          buyer_gmail_for_transfer: formData.buyerEmail,
          buyer_message: formData.message,
          amount: listing.price,
          payment_method: 'pending',
          status: 'pending'
        });

      if (orderError) throw orderError;

      // Create message record for admin
      const messageContent = `
🛒 New Purchase Request

Order ID: ${transactionId}
Channel/Listing: ${listing.title}
Listing Price: $${Number(listing.price).toLocaleString()}

Buyer Information:
- Email: ${formData.buyerEmail}
- Contact: ${formData.buyerContact}

Message from Buyer:
${formData.message || 'No additional message'}
      `.trim();

      const { error: messageError } = await supabase
        .from('messages')
        .insert({
          message_id: messageId,
          transaction_id: transactionId,
          user_type: 'buyer',
          user_contact: formData.buyerEmail,
          content: messageContent,
          message_type: 'text',
          status: 'active'
        });

      if (messageError) throw messageError;

      setSubmitted(true);
      toast({
        title: "Request Sent!",
        description: "Your purchase request has been sent to the admin. You will be contacted shortly.",
      });

      setTimeout(() => {
        setSubmitted(false);
        onOpenChange(false);
        setFormData({ buyerEmail: '', buyerContact: '', message: '' });
      }, 3000);

    } catch (error) {
      console.error('Error submitting purchase request:', error);
      toast({
        title: "Error",
        description: "Failed to submit purchase request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[500px]">
          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-foreground">Request Submitted!</h3>
              <p className="text-muted-foreground">
                We've received your purchase request for <span className="font-semibold">{listing.title}</span>.
                The admin will contact you shortly via your email.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>Request to Buy - {listing.title}</DialogTitle>
          <DialogDescription>
            Fill in your details to submit a purchase request. The admin will review and contact you.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Listing Info */}
          <div className="bg-muted p-4 rounded-lg space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Listing:</span>
              <span className="font-semibold text-foreground">{listing.title}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Price:</span>
              <span className="text-xl font-bold text-orange-primary">
                ${Number(listing.price).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="buyerEmail">Your Email *</Label>
              <Input
                id="buyerEmail"
                type="email"
                placeholder="your.email@example.com"
                value={formData.buyerEmail}
                onChange={(e) => setFormData({ ...formData, buyerEmail: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="buyerContact">Contact Number (WhatsApp/Phone) *</Label>
              <Input
                id="buyerContact"
                type="tel"
                placeholder="+1 234 567 8900"
                value={formData.buyerContact}
                onChange={(e) => setFormData({ ...formData, buyerContact: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="message">Message to Admin</Label>
              <Textarea
                id="message"
                placeholder="Tell us about your interest in this channel, any questions, or special requests..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={4}
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-orange-primary hover:bg-orange-primary/90 text-white"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Request'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
