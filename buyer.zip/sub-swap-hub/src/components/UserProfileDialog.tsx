import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { User as SupabaseUser } from "@supabase/supabase-js";
import { User, DollarSign, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface UserProfileDialogProps {
  user: SupabaseUser;
  profile: any;
}

export const UserProfileDialog = ({ user, profile }: UserProfileDialogProps) => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setOpen(false);
    navigate('/');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 border-2 hover:bg-accent">
          <User className="h-4 w-4" />
          Profile
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader className="space-y-3">
          <DialogTitle className="text-2xl font-bold">User Profile</DialogTitle>
          <DialogDescription className="text-base">
            Manage your account information and settings
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-2 h-12">
            <TabsTrigger value="overview" className="text-base">Overview</TabsTrigger>
            <TabsTrigger value="account" className="text-base">Account Details</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-5 mt-6">
            {/* Profile Info Card */}
            <Card className="border-2">
              <CardHeader className="pb-4">
                <CardTitle className="text-xl flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Profile Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 items-center py-3 border-b">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">Username</span>
                  <span className="font-semibold text-base col-span-2">{profile?.username || 'Not set'}</span>
                </div>
                <div className="grid grid-cols-3 gap-4 items-center py-3">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">Gmail ID</span>
                  <span className="font-semibold text-base col-span-2 break-all">{user.email}</span>
                </div>
              </CardContent>
            </Card>

            {/* Balance Card */}
            <Card className="border-2 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
              <CardHeader className="pb-4">
                <CardTitle className="text-xl flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-600" />
                  Account Balance
                </CardTitle>
                <CardDescription className="text-sm">
                  Balance can only be added by admin
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <p className="text-4xl font-bold text-green-600 dark:text-green-400">
                    ${(profile?.balance || 0).toFixed(2)}
                  </p>
                  <p className="text-sm text-muted-foreground mt-2 font-medium">USD</p>
                </div>
              </CardContent>
            </Card>

            {/* Logout Button */}
            <Button 
              onClick={handleSignOut}
              variant="destructive"
              size="lg"
              className="w-full h-12 text-base font-semibold"
            >
              <LogOut className="h-5 w-5 mr-2" />
              Logout
            </Button>
          </TabsContent>

          <TabsContent value="account" className="space-y-5 mt-6">
            <Card className="border-2">
              <CardHeader className="pb-4">
                <CardTitle className="text-xl flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Complete Account Details
                </CardTitle>
                <CardDescription className="text-sm">
                  All information about your account
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-1">
                <div className="grid grid-cols-3 gap-4 items-center py-3 border-b">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">Username</span>
                  <span className="text-base font-semibold col-span-2">{profile?.username || 'Not set'}</span>
                </div>
                <div className="grid grid-cols-3 gap-4 items-center py-3 border-b">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">Gmail ID</span>
                  <span className="text-base font-semibold col-span-2 break-all">{user.email}</span>
                </div>
                <div className="grid grid-cols-3 gap-4 items-center py-3 border-b">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">Display Name</span>
                  <span className="text-base font-semibold col-span-2">{profile?.display_name || 'Not set'}</span>
                </div>
                <div className="grid grid-cols-3 gap-4 items-center py-3 border-b">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">User ID</span>
                  <span className="text-sm font-mono text-muted-foreground col-span-2 break-all">{user.id}</span>
                </div>
                <div className="grid grid-cols-3 gap-4 items-center py-3">
                  <span className="text-sm font-medium text-muted-foreground col-span-1">Balance</span>
                  <span className="text-base font-semibold text-green-600 dark:text-green-400 col-span-2">
                    ${(profile?.balance || 0).toFixed(2)} USD
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Logout Button */}
            <Button 
              onClick={handleSignOut}
              variant="destructive"
              size="lg"
              className="w-full h-12 text-base font-semibold"
            >
              <LogOut className="h-5 w-5 mr-2" />
              Logout
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};