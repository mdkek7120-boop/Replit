import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { User, Edit2, Check, X, Loader2 } from "lucide-react";
import { User as SupabaseUser } from "@supabase/supabase-js";

interface UserProfileProps {
  user: SupabaseUser;
  profile: any;
  onProfileUpdate?: (profile: any) => void;
}

export const UserProfile = ({ user, profile, onProfileUpdate }: UserProfileProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [username, setUsername] = useState(profile?.username || "");
  const [displayName, setDisplayName] = useState(profile?.display_name || "");
  const [loading, setLoading] = useState(false);
  const [usernameError, setUsernameError] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    setUsername(profile?.username || "");
    setDisplayName(profile?.display_name || "");
  }, [profile]);

  const validateUsername = (value: string) => {
    if (value.length < 3) {
      return "Username must be at least 3 characters long";
    }
    if (value.length > 30) {
      return "Username must be less than 30 characters";
    }
    if (!/^[a-zA-Z0-9_]+$/.test(value)) {
      return "Username can only contain letters, numbers, and underscores";
    }
    return "";
  };

  const checkUsernameAvailability = async (value: string) => {
    if (value === profile?.username) return true;
    
    const { data, error } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', value)
      .neq('user_id', user.id);

    if (error) {
      console.error('Error checking username:', error);
      return false;
    }

    return data.length === 0;
  };

  const handleUsernameChange = (value: string) => {
    setUsername(value);
    const error = validateUsername(value);
    setUsernameError(error);
  };

  const handleSave = async () => {
    setLoading(true);
    
    try {
      // Validate username
      const validationError = validateUsername(username);
      if (validationError) {
        setUsernameError(validationError);
        setLoading(false);
        return;
      }

      // Check username availability
      const isAvailable = await checkUsernameAvailability(username);
      if (!isAvailable) {
        setUsernameError("This username is already taken");
        setLoading(false);
        return;
      }

      // Update profile
      const { data, error } = await supabase
        .from('profiles')
        .update({
          username,
          display_name: displayName,
        })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });

      setIsEditing(false);
      onProfileUpdate?.(data);
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setUsername(profile?.username || "");
    setDisplayName(profile?.display_name || "");
    setUsernameError("");
    setIsEditing(false);
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="w-16 h-16 bg-orange-primary text-white rounded-full flex items-center justify-center mx-auto mb-3">
          <User className="w-8 h-8" />
        </div>
        <CardTitle className="text-xl">User Profile</CardTitle>
        <CardDescription>Manage your account information</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Email</Label>
          <Input value={user.email} disabled className="bg-gray-50" />
        </div>

        <div className="space-y-2">
          <Label>Username</Label>
          <div className="flex gap-2">
            <Input
              value={username}
              onChange={(e) => handleUsernameChange(e.target.value)}
              disabled={!isEditing}
              placeholder="Enter your username"
              className={usernameError && isEditing ? "border-red-500" : ""}
            />
          </div>
          {usernameError && isEditing && (
            <p className="text-sm text-red-500">{usernameError}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label>Display Name</Label>
          <Input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            disabled={!isEditing}
            placeholder="Enter your display name"
          />
        </div>

        <div className="flex gap-2 pt-4">
          {!isEditing ? (
            <Button
              onClick={() => setIsEditing(true)}
              className="w-full bg-orange-primary hover:bg-orange-primary/90"
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          ) : (
            <>
              <Button
                onClick={handleSave}
                disabled={loading || !!usernameError}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Check className="w-4 h-4 mr-2" />
                )}
                Save
              </Button>
              <Button
                onClick={handleCancel}
                variant="outline"
                disabled={loading}
                className="flex-1"
              >
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};