import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Send, Paperclip, Mic, Image, MessageCircle, X, Minimize2 } from "lucide-react";
import { useChat } from '@/hooks/useChat';
import { supabase } from '@/integrations/supabase/client';

interface ChatWidgetProps {
  isLoggedIn?: boolean;
  userEmail?: string;
  userType?: 'buyer' | 'seller';
  defaultExpanded?: boolean;
  className?: string;
}

const ChatWidget = ({ 
  isLoggedIn = false, 
  userEmail, 
  userType = 'seller',
  defaultExpanded = false,
  className = ""
}: ChatWidgetProps) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [newMessage, setNewMessage] = useState('');
  const [guestContact, setGuestContact] = useState('');
  const [showContactInput, setShowContactInput] = useState(!isLoggedIn);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { messages, conversationId, sendMessage, syncAnonymousMessages } = useChat(isLoggedIn, userEmail);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Sync anonymous messages when user logs in
  useEffect(() => {
    if (isLoggedIn && userEmail) {
      syncAnonymousMessages(userEmail);
    }
  }, [isLoggedIn, userEmail, syncAnonymousMessages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;
    
    const contactInfo = isLoggedIn ? userEmail : guestContact;
    if (!contactInfo?.trim()) {
      alert('Please provide your contact information');
      return;
    }

    const success = await sendMessage(
      newMessage,
      'text',
      undefined,
      contactInfo,
      userType
    );

    if (success) {
      setNewMessage('');
      if (!isLoggedIn && guestContact && !showContactInput) {
        setShowContactInput(false);
      }
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const contactInfo = isLoggedIn ? userEmail : guestContact;
    if (!contactInfo?.trim()) {
      alert('Please provide your contact information before uploading files');
      return;
    }

    const type = file.type.startsWith('image/') ? 'image' : 'audio';
    await sendMessage(
      `Uploaded ${type}: ${file.name}`,
      type,
      file,
      contactInfo,
      userType
    );
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  if (!isExpanded) {
    return (
      <div className={`fixed bottom-4 right-4 z-50 ${className}`}>
        <Button
          onClick={() => setIsExpanded(true)}
          className="rounded-full w-14 h-14 bg-orange-primary hover:bg-orange-primary/90 shadow-lg"
        >
          <MessageCircle className="w-6 h-6 text-white" />
          {messages.length > 0 && (
            <Badge className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white border-2 border-white">
              {messages.length}
            </Badge>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className={`fixed bottom-4 right-4 z-50 ${className}`}>
      <Card className="w-80 h-96 flex flex-col shadow-xl border-0 bg-white">
        <CardHeader className="border-b p-3 bg-orange-primary text-white">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold">Support Chat</CardTitle>
              <p className="text-xs opacity-90">ID: {conversationId?.split('-')[1]}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-white/20 text-white text-xs">
                Online
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(false)}
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
              >
                <Minimize2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col p-0">
          {/* Contact Input for Guest Users */}
          {!isLoggedIn && showContactInput && (
            <div className="border-b p-3 bg-gray-50">
              <label className="block text-xs font-medium mb-1 text-gray-700">
                Your Email/Phone (Required)
              </label>
              <Input
                value={guestContact}
                onChange={(e) => setGuestContact(e.target.value)}
                placeholder="Enter your contact info"
                className="text-sm h-8"
              />
            </div>
          )}

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-gray-50">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 text-sm mt-8">
                <MessageCircle className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p>Start a conversation with our team!</p>
                <p className="text-xs mt-1">We'll respond as soon as possible.</p>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] px-3 py-2 rounded-lg text-sm ${
                    message.sender === 'user'
                      ? 'bg-orange-primary text-white'
                      : 'bg-white text-gray-900 border border-gray-200'
                  }`}>
                    {message.message_type === 'image' && (
                      <div className="flex items-center mb-1">
                        <Image className="w-3 h-3 mr-1" />
                        <span className="text-xs opacity-75">Image</span>
                      </div>
                    )}
                    {message.message_type === 'audio' && (
                      <div className="flex items-center mb-1">
                        <Mic className="w-3 h-3 mr-1" />
                        <span className="text-xs opacity-75">Audio</span>
                      </div>
                    )}
                    <div>{message.content}</div>
                    <div className={`text-xs mt-1 ${
                      message.sender === 'user' ? 'text-orange-100' : 'text-gray-500'
                    }`}>
                      {formatTime(message.timestamp)}
                    </div>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
          
          {/* Input Area */}
          <div className="border-t p-3 bg-white">
            <div className="flex items-center space-x-2">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                className="text-gray-500 hover:text-gray-700 h-8 w-8 p-0"
              >
                <Paperclip className="w-4 h-4" />
              </Button>
              
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => audioInputRef.current?.click()}
                className="text-gray-500 hover:text-gray-700 h-8 w-8 p-0"
              >
                <Mic className="w-4 h-4" />
              </Button>
              
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 h-8 text-sm"
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              
              <Button 
                onClick={handleSendMessage}
                disabled={!newMessage.trim() || (!isLoggedIn && !guestContact.trim())}
                className="bg-orange-primary hover:bg-orange-primary/90 text-white h-8 w-8 p-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            {/* Hidden file inputs */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <input
              ref={audioInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatWidget;