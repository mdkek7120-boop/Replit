import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { 
  DollarSign, 
  Plus, 
  Minus, 
  History,
  TrendingUp,
  TrendingDown,
  ArrowUpCircle,
  ArrowDownCircle
} from 'lucide-react';

interface BalanceTransaction {
  id: string;
  user_id: string;
  admin_id: string | null;
  transaction_type: string;
  amount: number;
  balance_before: number;
  balance_after: number;
  reason: string | null;
  status: string;
  created_at: string;
}

interface BalanceManagementProps {
  userId: string;
  currentBalance: number;
  onBalanceUpdate: () => void;
}

export const BalanceManagement = ({ userId, currentBalance, onBalanceUpdate }: BalanceManagementProps) => {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showWithdrawDialog, setShowWithdrawDialog] = useState(false);
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [transactions, setTransactions] = useState<BalanceTransaction[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const fetchTransactions = async () => {
    try {
      setLoadingHistory(true);
      const { data, error } = await supabase
        .from('balance_transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setTransactions(data || []);
    } catch (error: any) {
      console.error('Error fetching transactions:', error);
      toast({
        title: "Error",
        description: "Failed to load transaction history",
        variant: "destructive"
      });
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (showHistoryDialog) {
      fetchTransactions();
    }
  }, [showHistoryDialog]);

  const handleAddBalance = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0",
        variant: "destructive"
      });
      return;
    }

    if (!reason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for adding balance",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const { error } = await supabase.rpc('add_user_balance', {
        p_user_id: userId,
        p_amount: parseFloat(amount),
        p_reason: reason.trim()
      });

      if (error) throw error;

      toast({
        title: "Balance Added",
        description: `$${amount} has been added successfully`,
      });

      setShowAddDialog(false);
      setAmount('');
      setReason('');
      onBalanceUpdate();
    } catch (error: any) {
      console.error('Error adding balance:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to add balance",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleWithdrawBalance = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0",
        variant: "destructive"
      });
      return;
    }

    if (parseFloat(amount) > currentBalance) {
      toast({
        title: "Insufficient Balance",
        description: "Withdrawal amount exceeds current balance",
        variant: "destructive"
      });
      return;
    }

    if (!reason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for withdrawing balance",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const { error } = await supabase.rpc('withdraw_user_balance', {
        p_user_id: userId,
        p_amount: parseFloat(amount),
        p_reason: reason.trim()
      });

      if (error) throw error;

      toast({
        title: "Balance Withdrawn",
        description: `$${amount} has been withdrawn successfully`,
      });

      setShowWithdrawDialog(false);
      setAmount('');
      setReason('');
      onBalanceUpdate();
    } catch (error: any) {
      console.error('Error withdrawing balance:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to withdraw balance",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-4">
      {/* Balance Display Card */}
      <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 border-orange-200 dark:border-orange-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-900 dark:text-orange-100">
            <DollarSign className="h-5 w-5" />
            Current Balance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold text-orange-600 dark:text-orange-400 mb-4">
            {formatCurrency(currentBalance)}
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => setShowAddDialog(true)}
              className="flex-1 bg-green-600 hover:bg-green-700"
              data-testid="button-add-balance"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Balance
            </Button>
            <Button
              onClick={() => setShowWithdrawDialog(true)}
              className="flex-1 bg-red-600 hover:bg-red-700"
              data-testid="button-withdraw-balance"
            >
              <Minus className="w-4 h-4 mr-2" />
              Withdraw
            </Button>
            <Button
              onClick={() => setShowHistoryDialog(true)}
              variant="outline"
              className="flex-1"
              data-testid="button-view-history"
            >
              <History className="w-4 h-4 mr-2" />
              History
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Add Balance Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-600">
              <ArrowUpCircle className="w-5 h-5" />
              Add Balance
            </DialogTitle>
            <DialogDescription>
              Add funds to the user's account balance
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="add-amount">Amount ($)</Label>
              <Input
                id="add-amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                data-testid="input-add-amount"
              />
            </div>
            <div>
              <Label htmlFor="add-reason">Reason</Label>
              <Textarea
                id="add-reason"
                placeholder="Enter reason for adding balance..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                data-testid="textarea-add-reason"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAddDialog(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddBalance}
              disabled={loading}
              className="bg-green-600 hover:bg-green-700"
              data-testid="button-confirm-add"
            >
              {loading ? 'Adding...' : 'Add Balance'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Withdraw Balance Dialog */}
      <Dialog open={showWithdrawDialog} onOpenChange={setShowWithdrawDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <ArrowDownCircle className="w-5 h-5" />
              Withdraw Balance
            </DialogTitle>
            <DialogDescription>
              Withdraw funds from the user's account balance
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-3 bg-muted rounded-md">
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <p className="text-2xl font-bold">{formatCurrency(currentBalance)}</p>
            </div>
            <div>
              <Label htmlFor="withdraw-amount">Amount ($)</Label>
              <Input
                id="withdraw-amount"
                type="number"
                step="0.01"
                min="0"
                max={currentBalance}
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                data-testid="input-withdraw-amount"
              />
            </div>
            <div>
              <Label htmlFor="withdraw-reason">Reason</Label>
              <Textarea
                id="withdraw-reason"
                placeholder="Enter reason for withdrawing balance..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                data-testid="textarea-withdraw-reason"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowWithdrawDialog(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleWithdrawBalance}
              disabled={loading}
              className="bg-red-600 hover:bg-red-700"
              data-testid="button-confirm-withdraw"
            >
              {loading ? 'Withdrawing...' : 'Withdraw Balance'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transaction History Dialog */}
      <Dialog open={showHistoryDialog} onOpenChange={setShowHistoryDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Transaction History
            </DialogTitle>
            <DialogDescription>
              View all balance transactions for this user
            </DialogDescription>
          </DialogHeader>
          <div className="overflow-auto max-h-96">
            {loadingHistory ? (
              <div className="p-8 text-center text-muted-foreground">
                Loading transactions...
              </div>
            ) : transactions.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                No transactions found
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell className="text-xs">
                        {formatDate(transaction.created_at)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={transaction.transaction_type === 'add' ? 'default' : 'destructive'}
                          className={
                            transaction.transaction_type === 'add'
                              ? 'bg-green-600'
                              : 'bg-red-600'
                          }
                        >
                          {transaction.transaction_type === 'add' ? (
                            <TrendingUp className="w-3 h-3 mr-1" />
                          ) : (
                            <TrendingDown className="w-3 h-3 mr-1" />
                          )}
                          {transaction.transaction_type.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell className={
                        transaction.transaction_type === 'add' 
                          ? 'text-green-600 font-semibold' 
                          : 'text-red-600 font-semibold'
                      }>
                        {transaction.transaction_type === 'add' ? '+' : '-'}
                        {formatCurrency(transaction.amount)}
                      </TableCell>
                      <TableCell className="text-sm">
                        <div className="flex flex-col">
                          <span className="text-muted-foreground text-xs">
                            {formatCurrency(transaction.balance_before)}
                          </span>
                          <span className="font-medium">
                            {formatCurrency(transaction.balance_after)}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-sm">
                        {transaction.reason || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {transaction.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
