import { useEffect, useState } from "react";
import parrotImage from "@/assets/parrot-celebration.png";

interface ParrotCelebrationProps {
  show: boolean;
  onComplete?: () => void;
}

export const ParrotCelebration = ({ show, onComplete }: ParrotCelebrationProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (show) {
      setIsVisible(true);
      const timer = setTimeout(() => {
        setIsVisible(false);
        onComplete?.();
      }, 3000); // Show for 3 seconds

      return () => clearTimeout(timer);
    }
  }, [show, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] animate-fade-in">
      <div className="bg-white rounded-2xl p-8 text-center animate-scale-in">
        <div className="animate-bounce mb-4">
          <img 
            src={parrotImage} 
            alt="Celebration Parrot" 
            className="w-32 h-32 mx-auto"
          />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          🎉 Welcome to YT Market!
        </h2>
        <p className="text-gray-600">
          Your account has been created successfully!<br />
          Please check your email for confirmation.
        </p>
      </div>
    </div>
  );
};