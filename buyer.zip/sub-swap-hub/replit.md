# YT Market - YouTube Channel Marketplace

## Overview
This is a YouTube channel marketplace application where users can buy and sell YouTube channels. The platform features channel listings, messaging system, admin dashboard, and authentication.

**Last Updated:** October 3, 2025

## Project Architecture

### Tech Stack
- **Frontend:** React 18 + TypeScript
- **Build Tool:** Vite 5
- **UI Framework:** shadcn/ui components with Radix UI primitives
- **Styling:** Tailwind CSS
- **Routing:** React Router v6
- **State Management:** TanStack Query (React Query v5)
- **Backend:** Supabase (Database, Auth, Storage)
- **Forms:** React Hook Form with Zod validation

### Project Structure
```
src/
├── assets/              # Static assets (images, logos)
├── components/          # React components
│   ├── marketplace/    # Marketplace-specific components
│   └── ui/             # shadcn/ui components
├── hooks/              # Custom React hooks
├── integrations/       # Third-party integrations
│   └── supabase/      # Supabase client and types
├── lib/               # Utility functions
├── pages/             # Page components
├── App.tsx            # Main app component
└── main.tsx           # Entry point

supabase/
└── migrations/        # Database migrations
```

### Key Features
1. Channel listings marketplace with filtering and search
2. User authentication and profiles
3. Messaging system for buyers/sellers
4. Admin dashboard for platform management
5. Channel selling workflow
6. Category-based browsing

## Replit Environment Setup

### Development Server
- **Port:** 5000
- **Host:** 0.0.0.0 (required for Replit proxy)
- **Command:** `npm run dev`
- **Workflow:** "Start application" configured with webview output

### Vite Configuration
The vite.config.ts has been configured for Replit:
- Server binds to 0.0.0.0:5000
- `allowedHosts: true` - Required for Replit proxy to work
- HMR configured for port 5000
- Strict port enabled to prevent conflicts

### Deployment Configuration
- **Type:** Autoscale (stateless web application)
- **Build:** `npm run build`
- **Run:** `npx vite preview --host 0.0.0.0 --port 5000`

## Backend Integration

### Supabase
The application uses Supabase for:
- PostgreSQL database
- Authentication (email/password, OAuth)
- Real-time subscriptions
- Row Level Security (RLS)

**Database Schema** includes:
- users/profiles
- channel_listings
- transactions
- messages
- categories

## Development Guidelines

### Running Locally
```bash
npm run dev        # Start development server on port 5000
npm run build      # Build for production
npm run preview    # Preview production build
npm run lint       # Run ESLint
```

### Important Notes
- The Supabase URL and publishable key are already configured in `src/integrations/supabase/client.ts`
- The application is configured to work with Replit's proxy system
- All dependencies are managed via npm (Node.js project)
- TypeScript strict mode is enabled

## Admin Access

### Admin Credentials
Two admin accounts are available:
- **Primary Admin:** creditcoinhub@gmail.com / Admin@12345
- **Secondary Admin:** mdkek7120@gmail.com / Ra1234567890

### First Time Setup
1. Go to `/admin/setup`
2. Select which admin account to create (Primary or Secondary)
3. Click "Create Admin Account" button
4. Wait for success message
5. Go to `/admin/login` and login with the selected credentials

**Important Notes:**
- If account already exists, you'll be redirected to login page
- The setup page shows both available admin accounts with their credentials
- Admin routing: `/admin` → `/admin/login` → `/admin/dashboard`

### Admin Panel Features
- User management (ban/unban users)
- Create and manage channel listings
- View and respond to messages
- Track all transactions
- Seed sample data for testing
- Password reset functionality via "Forgot Password?" link

## User Authentication System

### Features
- **Modern UI/UX:** Beautiful gradient design with smooth animations
- **User Registration:** Create account with email, username, and password
- **User Login:** Secure authentication with email and password
- **Password Reset:** Forgot password functionality with email verification
- **Password Strength:** Real-time password strength indicator
- **Username Validation:** Instant feedback on username availability
- **Email Verification:** Automatic verification emails sent on signup
- **Visual Feedback:** Icons, progress bars, and success/error messages

### Authentication Pages
- `/auth` - Main authentication page (Sign In / Sign Up)
- Password reset flow integrated within auth page

## YouTube Auto-Fetch Feature
- Automatically retrieves YouTube channel data (subscriber count, channel name) when user submits a channel URL
- Supports multiple URL formats: /channel/, /@handle, /user/, /c/
- Uses YouTube Data API v3 with secure API key storage
- Provides real-time feedback with loading states and success indicators

## Order ID System
- Generates unique Order IDs in format: ORD-{timestamp}-{random}
- Displayed on submission confirmation page
- Used for tracking and messaging with admin

## Messaging System
- Secure storage in Supabase database (automatic backups)
- Real-time updates using Supabase subscriptions
- LocalStorage fallback for anonymous users (syncs on login)
- Messages are never lost - dual storage approach ensures reliability
- Admin can view and respond to all messages

## Recent Changes
- **2025-10-03:** Implemented Advanced Messaging System & Dark Theme
  - **Profile Avatar System:** Added circular profile avatars to all messages with fallback initials
  - **Clickable User Profiles:** Created full profile view at /profile/:userId with message history
  - **Dark Theme Design:** Applied accs-market.com style dark purple/black gradient theme
  - **Realtime Messaging Fix:** Fixed subscription closure issue for proper real-time updates
  - **Enhanced MessageAdmin:** Redesigned with conversation list, search, smart time formatting
  - **User Profile Component:** New component showing user details, message history, and listings
  - **Marketplace Cards:** Updated ChannelCard with modern dark theme design
- **2025-10-03:** Completed Admin Panel Full Update
  - **Admin Routing Fix:** Fixed `/admin` route to properly redirect to `/admin/login` instead of loading empty screen
    - Clean routing flow: `/admin` → `/admin/login` → `/admin/dashboard`
  - **Multi-Admin Support:** Enhanced setup page to support multiple admin accounts
    - Added radio button selection between Primary and Secondary admin
    - Clear display of both admin email addresses and passwords
  - **Existing Account Handling:** Improved AdminSetup to gracefully handle existing accounts
    - Instead of failing, now shows success message and redirects to login
    - Removed problematic automatic login with potentially incorrect password
  - **Password Reset:** Added full password reset functionality to admin login
    - "Forgot Password?" button triggers Supabase password reset email
    - Success/error feedback with toast notifications
    - Email validation before sending reset link
  - **Better UX:** Enhanced error messages and user guidance throughout admin flow
    - Both admin emails displayed on login page for reference
    - Helpful error messages guide users to correct actions
    - Smooth transitions between setup and login pages
- **2025-10-03:** Implemented Automatic Submission-to-Message System
  - **Sell Channel Flow:** User submissions now automatically create formatted messages in admin inbox
    - All submission details (Order ID, channel info, price, contact, etc.) sent as message
    - User sees complete submission details on confirmation page
    - Admin receives structured message with emoji header for easy identification
  - **Buy Channel Flow:** Purchase requests create formatted messages in admin inbox
    - Buyer details (email, contact, message) sent as structured message
    - Consistent formatting with sell flow for uniformity
  - **Conversation Threading:** Two-way messaging system fully functional
    - User submissions appear in admin message box
    - Admin can reply directly to submissions
    - Users see admin replies in real-time via ChatWidget and Messages page
    - All messages linked by Order ID/Transaction ID for threaded conversations
  - **User Confirmation:** Enhanced confirmation page shows all submitted details
    - Complete submission record for user's reference
    - Clear "Your submission was sent to admin" messaging
    - Direct link to message admin for follow-up questions
- **2025-10-03:** Implemented YouTube Channel Marketplace improvements
  - **YouTube Auto-Fetch:** Added automatic channel data fetching using YouTube Data API v3
    - Supports multiple URL formats: /channel/, /@handle, /user/, /c/
    - Auto-populates subscriber count and channel name
    - Provides real-time loading states and success feedback
  - **Order ID System:** Implemented unique Order ID generation (ORD-{timestamp}-{random})
    - Displayed on submission confirmation page
    - Used for tracking and messaging with admin
  - **Price Validation:** Enhanced asking price input with strict numeric validation
    - Changed to number input type for better UX
    - Added validation to prevent invalid price submissions
    - Ensures correct price storage in database
  - **Messaging System:** Verified secure message storage
    - Messages stored in Supabase database (automatic backups)
    - Real-time updates using Supabase subscriptions
    - LocalStorage fallback for anonymous users with sync on login
  - **UI/UX Improvements:** Enhanced overall user experience
    - Modern, clean design across all pages
    - Better form validation with helpful error messages
    - Improved visual feedback for all interactions
- **2025-10-03:** Enhanced user authentication system
  - Added password reset/forgot password functionality
  - Implemented password strength indicator with visual feedback
  - Added real-time username validation with availability check
  - Improved UI with gradient backgrounds and modern design
  - Added icons for better visual clarity (Mail, Lock, User, Eye/EyeOff)
  - Implemented email verification notifications
  - Enhanced form validation with better error messages
- **2025-10-03:** Updated admin authentication system
  - Changed admin email to creditcoinhub@gmail.com
  - Created dedicated admin setup page at /admin/setup
  - Improved login flow with clearer error messages
  - Added console logging for debugging auth issues
- **2025-10-03:** Initial Replit setup
  - Configured Vite to bind to 0.0.0.0:5000
  - Set up "Start application" workflow with webview output
  - Configured deployment for autoscale with proper build/run commands
  - Verified application runs successfully in Replit environment
